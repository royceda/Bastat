import data.mediator.DBMediator;
import data.dao.DBManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.model.Joueur;
import java.util.Date;
import java.util.List;

public class TestJoueur{


    TestJoueur(){
    }

    public static void main(String[] args){
	

	
	System.out.println("Instanciation:\t OK");
	

	DBManager DB = new DBManager();
	System.out.println("DBManager:\t OK"); // mettre le constructeur en public avant

	DBMediator.addOrModifyShoot(s1);
	DBMediator.addOrModifyShoot(s2);
	DBMediator.addOrModifyShoot(s3);
	System.out.println("Ajout:\t\t OK");
	

	Joueur J777 = DBMediator.getJoueur(12);//a finir
	System.out.println("Get:\t\t OK");
	
	DBMediator.deleteAllJoueur();  
	System.out.println("Delete:\t\t OK");
	
    }
}

import data.mediator.DBMediator;
import data.dao.DBManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.model.Joueur;
import java.util.Date;
import java.util.List;

public class TestAction{


    TestJoueur(){
    }

    public static void main(String[] args){

	System.out.println("Test Shoot:");
	
	System.out.println("  Instanciation:\t OK");

	DBManager DB = new DBManager();
	System.out.println("  DBManager:\t OK"); // mettre le constructeur en public avant

	DBMediator.addOrModifyAction(A1);
	DBMediator.addOrModifyAction(A2);
	DBMediator.addOrModifyAction(A3);
	System.out.println("  Ajout:\t\t OK");
      


	System.out.println("  Get:\t\t OK");
	
	DBMediator.deleteAllAction();  
	System.out.println("  Delete:\t\t OK");
	

	System.out.println("Test Faute:");


	System.out.println("Test Rebond:");

    }
}

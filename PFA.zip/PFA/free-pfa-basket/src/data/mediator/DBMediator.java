package data.mediator;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import data.dao.DBManager;

import data.dao.IJoueurDAO;
import data.dao.IActionDAO;
//import data.dao.IFormationDAO;
//import data.dao.IMatchDAO;
//import data.dao.ITeamDAO;

// ou import data.dao.*



import data.dao.db.DBJoueurDAO;
import data.dao.db.DBActionDAO;
import data.dao.db.DBShootDAO;
//import data.dao.db.DBTeamDAO;
//import data.dao.db.DBMatchDAO;


import data.model.Joueur;
import data.model.Action;
import data.model.Shoot;
//import data.model.Equipe;
//import data.model.Match;
//import data.model.Formation;


public class DBMediator {

 private static final Logger LOGGER = Logger.getLogger(DBMediator.class.getName());
    
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    
    public DBMediator(){}
  
    /*__________________________Joueur____________________*/


    public static List<Joueur> getJoueurs() {
	LOGGER.log(Level.INFO, "Getting Joueur List");


	List<Joueur> joueurs = DBManager.INSTANCE.getJoueurDAO().getJoueurs();	
	return joueurs;     
    }
    
    
    public static Joueur getJoueur(int id) {
	LOGGER.log(Level.INFO, "Getting Joueur element");
	Joueur joueur = DBManager.INSTANCE.getJoueurDAO().getJoueur(id);	
	return joueur;
    }
    
  	
    public static boolean addOrModifyJoueur(Joueur joueur) {
	LOGGER.log(Level.INFO, "Adding or modifying Joueur element");
	
	boolean success;
	success = DBManager.INSTANCE.getJoueurDAO().addOrModify(joueur);
	return success;
    }
    
    public static boolean deleteAllJoueur(){
	LOGGER.log(Level.INFO, "Deleting all Joueur element");
	
	boolean success;
	success = DBManager.INSTANCE.getJoueurDAO().deleteAllJoueur();
	return success;	
    }

    /*________________________Action_______________________*/
    
    public static List<Action> getActions() {
	LOGGER.log(Level.INFO, "Getting Action List");
	
	List<Action> actions = DBManager.INSTANCE.getActionDAO().getActions();	
	return actions;     
    }
    
    
    public static Action getAction(int id) {
	LOGGER.log(Level.INFO, "Getting Action element");
	
	Action action = DBManager.INSTANCE.getActionDAO().getAction(id);	
	return action;
    }
    
    
    public static boolean addOrModifyAction(Action action) {
	LOGGER.log(Level.INFO, "Adding or modifying Action element");
	
	boolean success;
	success = DBManager.INSTANCE.getActionDAO().addOrModify(action);	
	return success;
    }
    
    public static boolean deleteAllAction(){
	LOGGER.log(Level.INFO, "Deleting all Action element");
	
	boolean success;
	success = DBManager.INSTANCE.getActionDAO().deleteAllAction();
	return success;	
    }

    /*_________________________SHOOT______________________________*/

    public static List getShoots() {
	LOGGER.log(Level.INFO, "Getting Shoot element");
	List<Shoot> shoots = DBManager.INSTANCE.getShootDAO().getShoots();	
	return shoots;     
    }
    
    
    public static Shoot getShoot(int id) {
	LOGGER.log(Level.INFO, "Getting Shoot element");
	Shoot shoot = DBManager.INSTANCE.getShootDAO().getShoot(id);	
	return shoot;
    }
    
    
    public static boolean addOrModifyShoot(Shoot shoot) {
	LOGGER.log(Level.INFO, "Adding or modifying Shoot element");
	
	boolean success;
	success = DBManager.INSTANCE.getShootDAO().addOrModify(shoot);
	
	return success;
    }
    
    public static boolean deleteAllShoot(){
	LOGGER.log(Level.INFO, "Deleting all Shoot element");
	
	boolean success;
	success = DBManager.INSTANCE.getShootDAO().deleteAllShoot();

	return success;	
    }





    /*___________________________Equipe________________*/
    
      
    /* public static boolean parseInitDB(String initDBPath) {
	LOGGER.log(Level.INFO, "Parsing init DB file: " + initDBPath);
	
	String initDBStream;
	try {
	    initDBStream = ServletToolkit.readFile(initDBPath);
	} catch (IOException e) {
	    LOGGER.log(Level.SEVERE, "Error while parsing init DB file");
	    initDBStream = null;
	}
	
	if (initDBStream != null) {
	    return importXMLJoueurs(initDBStream);
	} else {
	    return false;
	}
	} */ 




}

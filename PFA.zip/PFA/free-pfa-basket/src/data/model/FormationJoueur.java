package data.model;

class FormationJoueur {

    private int    formationId;
    private int    joueurId;
    private String numero;


    //constructor
    public FormationJoueur() {
    }
    
    public FormationJoueur(int f, int j, String n){
	formationId = f;
	joueurId  = j;
	numero    = n;
    }


    //getter
    public int getFormation() {
	return this.formation;
    }
    
    public int getJoueur() {
	return this.joueur;
    }
    
    public String getNumero() {
	return this.numero;
    }

    //setter
    public void setFormation(int formation) {
	this.formationId = formation;
    }

    public void setJoueur(int joueur) {
	this.joueurId = joueur;
    }
    
    public void setNumero(String numero) {
	this.numero = numero;
    }

}

package data.model;

class Equipe {
<<<<<<< .mine
=======
    int id;
    String nom;
    String couleur;
    String photo;
>>>>>>> .r101

<<<<<<< .mine
    public static int NO_ID = -1;
    
    int id;
    String nom;
    String couleur;
    String photo;
    
    //constructor
    public Equipe() {
	
    }
    
    public Equipe(String nom, String couleur, String photo) {
	this.nom = nom;
	this.couleur = couleur;
	this.photo = photo;
    }
    
    //getter
    public String getNom() {
	return this.nom;
    }
    
    public String getCouleur() {
	return this.couleur;
    }
=======
    //constructor
    Equipe() {
>>>>>>> .r101

<<<<<<< .mine
    public String getPhoto() {
	return this.photo;
    }
=======
    }
>>>>>>> .r101

<<<<<<< .mine
    //setter
    public void setNom(String nom) {
	this.nom = nom;
    }
=======
    Equipe(String nom, String couleur, String photo) {
	this.nom = nom;
	this.couleur = couleur;
	this.photo = photo;
    }
>>>>>>> .r101

<<<<<<< .mine
    public void setCouleur(String couleur) {
	this.couleur = couleur;
    }
=======
    //getter
    String getNom() {
	return this.nom;
    }
>>>>>>> .r101

<<<<<<< .mine
    public void setPhoto(String photo) {
	this.photo = photo;
    }
}
=======
    String getCouleur() {
	return this.couleur;
    }

    String getPhoto() {
	return this.photo;
    }

    //setter
    void setNom(String nom) {
	this.nom = nom;
    }

    void setCouleur(String couleur) {
	this.couleur = couleur;
    }

    void setPhoto(String photo) {
	this.photo = photo;
    }

    public void setId(int i){
	this.id = i;
    }
}
>>>>>>> .r101

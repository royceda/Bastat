package fr.basket.stat;

public class Contre extends Action {

    public static int NO_ID=-1;	
    private int id;
    private int actionId;

//constructor
	Contre() {
		super();
	}
}

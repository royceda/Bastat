package fr.basket.stat;

public class Interception extends Action {
    public static int NO_ID=-1;

    private int id;
    private int actionId;

	Interception() {
		super();
	}
}

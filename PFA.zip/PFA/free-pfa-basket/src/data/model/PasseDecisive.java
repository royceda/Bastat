package fr.basket.stat;

class PasseDecisive extends Action{

    public static int NO_ID=-1;

    private int id;
    private int actionId;

	PasseDecisive() {
		super();
	}

	PasseDecisive(TempsDeJeu temps, Joueur joueurActeur, Joueur joueurCible) {
		super(temps, joueurActeur, joueurCible);
	}

}


package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IActionDAO;
import data.dao.db.DBActionDAO;

import data.model.PasseDecisive;

public class DBPasseDecisiveDao extends DBPasseDecisiveDao{

    public static final  String TABLE_NAME             = "PASSE_DECISIVE";
    

    private static final String ID_FIELD_NAME          = "ID";
    private static final String ACTION_ID_FIELD_NAME   = "ACTION_ID";
  
   
     
    private static final String ID_FIELD_TYPE          = "INTEGER";
    private static final String ACTION_ID_FIELD_TYPE   = "INTEGER";
    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + ACTION_ID_FIELD_NAME     + " " + ACTION_ID_FIELD_TYPE ;

    private PreparedStatement GET_ALL_PASSES_DECISIVES_PSTATEMENT    = null;
    private PreparedStatement GET_PASSE_DECISIVE_PSTATEMENT         = null;
    private PreparedStatement UPDATE_PASSE_DECISIVE_PSTATEMENT      = null;
    private PreparedStatement INSERT_PASSE_DECISIVE_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_PASSES_DECISIVES_PSTATEMENT = null;

    private int lastId = PasseDecisive.NO_ID;

    
    public DBPasseDecisiveDAO(){}

    public PasseDecisive getPasseDecisive(int i){
	Collection<PasseDecisive> passes=getPassesWithIDFilter(id);
	PasseDecisive passe;
	if (passes.size() == 1) {
	    passe = passes.iterator().next();
	} else {
	    passe = null;
	}
	return passe;
    }


    private List<PasseDecisive> getPassesWithIDFilter(Integer id) {
	if (GET_ALL_PASSES_DECISIVES_PSTATEMENT == null) {
	    
	    GET_ALL_PASSES_DECISIVES_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										      + TABLE_NAME 
										      + " order by "
										      + ID_FIELD_NAME);
	}
	if (GET_PASSE_DECISIVE_PSTATEMENT == null) {
	    GET_PASSE_DECISIVE_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										+ TABLE_NAME 
										+ " where "
										+ ID_FIELD_NAME 
										+ "=?" 
										+ " order by " 
										+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_PASSE_DECISIVE_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_PASSES_DECISIVES_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Passes", e);
	    resultSet = null;
	}
	
	List<PasseDecisive> result;
	if (resultSet == null) {
	    result = new ArrayList<PasseDecisive>();
	} else {
	    result = new ArrayList<PasseDecisive>();
	    try {
		while (resultSet.next()) {
		    PasseDecisive passe = new PasseDecisive();
		    passe.setId(resultSet.getInt(ID_FIELD_NAME));
		    passe.setActionId(resultSet.getInt(ACTION_ID_FIELD_NAME));		    	    
		    //en tant que action		   
		    result.add(passe);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }


    public List<PasseDecisive> getPasses(){
	return getPassesWithIDFilter(null);
    }

    public boolean addOrModify(PasseDecisive passe){
	super.addOrModify(passe);
	boolean result;
	
	// ajout
	passe.setId(getNextPasseId());
	    
	try {
	    if (INSERT_PASSE_DECISIVE_PSTATEMENT == null) {
		//DBAction.super(getAction(actionId)); 
		INSERT_PASSE_DECISIVE_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										       + TABLE_NAME
										       + " ("
										       + ID_FIELD_NAME
										       + ", " 
										       + ACTION_ID_FIELD_NAME								                                                                                       + ") values (?, ?)");
	    } else {
		INSERT_PASSE_DECISIVE_PSTATEMENT.clearParameters();
	    }		
	    INSERT_PASSE_DECISIVE_PSTATEMENT.setInt(1, passe.getId());
	    INSERT_PASSE_DECISIVE_PSTATEMENT.setInt(2, passe.getActionId());
	

				
	    result = INSERT_PASSE_DECISIVE_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while inserting Passe", e);
	    result = false;
	}

	return result;
    }


    private int getNextPasseId() {
	if (lastId == PasseDecisive.NO_ID) {
	    Collection<PasseDecisive> passes = getPasses();
	    for (Iterator<PasseDecisive> passeIte = passes.iterator(); passeIte.hasNext();) {
		PasseDecisive passe = passeIte.next();
		if (passe.getId() > lastId) {
		    lastId = passe.getId();
		}
	    }
	}
	return ++lastId;
    }
    

    public boolean deleteAllPasse(){
	if (DELETE_ALL_PASSES_DECISIVES_PSTATEMENT == null) {
	    DELETE_ALL_PASSES_DECISIVES_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_PASSES_DECISIVES_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Passes", e);
	    result = false;
	}
	if (result) {
	    lastId = PasseDecisive.NO_ID;
	}
	return result;
    }
}

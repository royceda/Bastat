package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IActionDAO;
import data.model.Action;




public class DBActionDAO implements IActionDAO{

    private static final Logger LOGGER = Logger.getLogger(DBActionDAO.class.getName());
    
    public static final String TABLE_NAME                    = "ACTION";
    
    protected static final String ID_FIELD_NAME               = "ID";
    protected static final String TEMPS_DE_JEU_FIELD_NAME     = "TEMPS_DE_JEU";
    protected static final String TEMPS_FIELD_NAME            = "TEMPS";
    protected static final String JOUEUR_ACTEUR_ID_FIELD_NAME = "JOUEUR_ACTEUR_ID";
    protected static final String JOUEUR_CIBLE_ID_FIELD_NAME  = "JOUEUR_CIBLE_ID";
    protected static final String COMMENTAIRE_FIELD_NAME      = "COMMENTAIRE";
    protected static final String TYPE_FIELD_NAME             = "TYPE";
    protected static final String SPECIFIQUE_FIELD_NAME       = "SPECIFIQUE";
    
    protected static final String ID_FIELD_TYPE               = "INTEGER";
    protected static final String TEMPS_DE_JEU_FIELD_TYPE     = "INTEGER";
    protected static final String TEMPS_FIELD_TYPE            = "INTEGER";
    protected static final String JOUEUR_ACTEUR_ID_FIELD_TYPE = "INTEGER";
    protected static final String JOUEUR_CIBLE_ID_FIELD_TYPE  = "TEXT"; 
    protected static final String COMMENTAIRE_FIELD_TYPE      = "INTEGER"; 
    protected static final String TYPE_FIELD_TYPE             = "INTEGER";
    protected static final String SPECIFIQUE_FIELD_TYPE       = "TEXT"; 
   
    
    //a voir sur l'heritage
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + TEMPS_DE_JEU_FIELD_NAME     + " " + TEMPS_DE_JEU_FIELD_TYPE 
	+ ", " + TEMPS_FIELD_NAME            + " " + TEMPS_FIELD_TYPE 
	+ ", " + JOUEUR_ACTEUR_ID_FIELD_NAME + " " + JOUEUR_ACTEUR_ID_FIELD_TYPE 
	+ ", " + JOUEUR_CIBLE_ID_FIELD_NAME  + " " + JOUEUR_CIBLE_ID_FIELD_TYPE 
	+ ", " + COMMENTAIRE_FIELD_NAME      + " " + COMMENTAIRE_FIELD_TYPE 
	+ ", " + TYPE_FIELD_NAME             + " " + TYPE_FIELD_TYPE 
	+ ", " + SPECIFIQUE_FIELD_NAME       + " " + SPECIFIQUE_FIELD_TYPE ;
    

    private PreparedStatement GET_ALL_ACTIONS_PSTATEMENT    = null;
    private PreparedStatement GET_ACTION_PSTATEMENT         = null;
    private PreparedStatement UPDATE_ACTION_PSTATEMENT      = null;
    private PreparedStatement INSERT_ACTION_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_ACTIONS_PSTATEMENT = null;
    
    private int lastId = Action.NO_ID;
   

    /*__________________Methodes_____________________*/

    public DBActionDAO(){}


    public Action getAction(int id){ 
	Collection<Action> actions = getActionsWithIDFilter(id);
	Action action;
	if (actions.size() == 1) {
	    action = actions.iterator().next();
	} else {
	    action = null;
	}
	return action;
    }
    
    
    private List<Action> getActionsWithIDFilter(Integer id) {
	if (GET_ALL_ACTIONS_PSTATEMENT == null) {
	    GET_ALL_ACTIONS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									     + TABLE_NAME 
									     + " order by "
									     + ID_FIELD_NAME);
	}
	if (GET_ACTION_PSTATEMENT == null) {
	    GET_ACTION_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									+ TABLE_NAME 
									+ " where "
									+ ID_FIELD_NAME 
									+ "=?" 
									+ " order by " 
									+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_ACTION_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_ACTIONS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Actions", e);
	    resultSet = null;
	}
	
	List<Action> result;
	if (resultSet == null) {
	    result = new ArrayList<Action>();
	} else {
	    result = new ArrayList<Action>();
	    try {
		while (resultSet.next()) {
		    Action action = new Action();//Modif
		    action.setId(resultSet.getInt(ID_FIELD_NAME));
		    action.setTempsDeJeu(resultSet.getInt(TEMPS_DE_JEU_FIELD_NAME));
		    action.setTemps(resultSet.getInt(TEMPS_FIELD_NAME));
		    action.setJoueurActeur(resultSet.getInt(JOUEUR_ACTEUR_ID_FIELD_NAME));//Joueur
		    action.setType(resultSet.getInt(TYPE_FIELD_NAME));
		    action.setJoueurCible(resultSet.getInt(JOUEUR_CIBLE_ID_FIELD_NAME)); //Joueur
		    action.setCommentaire(resultSet.getString(COMMENTAIRE_FIELD_NAME));
		    action.setSpecifique(resultSet.getInt(SPECIFIQUE_FIELD_NAME));
		    
		    		    
		    result.add(action);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }
        
    public List<Action> getActions(){
	return getActionsWithIDFilter(null);
    }
    

    public boolean addOrModify(Action action){
	boolean result;
	
	if (action.getId() > action.NO_ID) {
	    // modification
	    try {
		if (UPDATE_ACTION_PSTATEMENT == null) {
		    UPDATE_ACTION_PSTATEMENT = DBManager.INSTANCE.prepareStatement("UPDATE " 
										   + TABLE_NAME 
										   + " SET "
										   + TEMPS_DE_JEU_FIELD_NAME 
										   + "=?, " 
										   + TEMPS_FIELD_NAME
										   + "=?, " 
										   + JOUEUR_ACTEUR_ID_FIELD_NAME 
										   + "=?, "
										   + JOUEUR_CIBLE_ID_FIELD_NAME 
										   + "=?, "
										   + SPECIFIQUE_FIELD_NAME
										   + "=?,"
										   + TYPE_FIELD_NAME 
										   + "=?, " 
										   + " where " 
										   + ID_FIELD_NAME 
										   + "=?");
		} else {
		    UPDATE_ACTION_PSTATEMENT.clearParameters();
		}
		//modif
		UPDATE_ACTION_PSTATEMENT.setInt(1, action.getId());
		UPDATE_ACTION_PSTATEMENT.setInt(2, action.getTempsDeJeu());
		UPDATE_ACTION_PSTATEMENT.setInt(3, action.getTemps());
		UPDATE_ACTION_PSTATEMENT.setInt(4, action.getJoueurActeur());	// Joueur.getId()
		UPDATE_ACTION_PSTATEMENT.setInt(5, action.getJoueurCible()); // " "
		UPDATE_ACTION_PSTATEMENT.setInt(6, action.getSpecifique());
		UPDATE_ACTION_PSTATEMENT.setInt(7, action.getType());

		
		//UPDATE_ACTION_PSTATEMENT.setInt(6, action.getPriority());
		//UPDATE_ACTION_PSTATEMENT.setInt(7, (action.isDone() ? IS_ACTION_DONE : IS_ACTION_NOT_DONE));
		result = UPDATE_ACTION_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while updating Action", e);
		result = false;
	    }
	   
	    
	} else {
	    // ajout
	    action.setId(getNextActionId());
	    
	    try {
		if (INSERT_ACTION_PSTATEMENT == null) {
		    INSERT_ACTION_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										   + TABLE_NAME + " ("
										   + ID_FIELD_NAME 
										   + ", " 
										   + TEMPS_DE_JEU_FIELD_NAME 
										   + ", " 
										   + TEMPS_FIELD_NAME 
										   + ", "
										   + JOUEUR_ACTEUR_ID_FIELD_NAME 
										   + ", " 
										   + JOUEUR_CIBLE_ID_FIELD_NAME 
										   + ", " 
										   + TYPE_FIELD_NAME 
										   + ", "
										   + SPECIFIQUE_FIELD_NAME
										   + ") values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
		} else {
		    INSERT_ACTION_PSTATEMENT.clearParameters();
		}
		
		INSERT_ACTION_PSTATEMENT.setInt(1, action.getId());
		INSERT_ACTION_PSTATEMENT.setInt(2, action.getTempsDeJeu());
		INSERT_ACTION_PSTATEMENT.setInt(3, action.getTemps());
		INSERT_ACTION_PSTATEMENT.setInt(4, action.getJoueurActeur()); //Joueur     
		INSERT_ACTION_PSTATEMENT.setInt(5, action.getJoueurCible()); //Joueur
		INSERT_ACTION_PSTATEMENT.setInt(6, action.getSpecifique());
		INSERT_ACTION_PSTATEMENT.setInt(7, action.getType());
		
		//INSERT_ACTION_PSTATEMENT.setInt(6, action.getPriority());
		//INSERT_ACTION_PSTATEMENT.setInt(7, (action.isDone() ? IS_ACTION_DONE : IS_ACTION_NOT_DONE));
				
		result = INSERT_ACTION_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while inserting Action", e);
		result = false;
	    }
	}
	return result;
    }
    
    private int getNextActionId() {
	if (lastId == Action.NO_ID) {
	    Collection<Action> actions = getActions();
	    for (Iterator<Action> actionIte = actions.iterator(); actionIte.hasNext();) {
		Action action = actionIte.next();
		if (action.getId() > lastId) {
		    lastId = action.getId();
		}
	    }
	}
	return ++lastId;
    }
    
   
    public boolean deleteAllAction(){
	if (DELETE_ALL_ACTIONS_PSTATEMENT == null) {
	    DELETE_ALL_ACTIONS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_ACTIONS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Actions", e);
	    result = false;
	}
	if (result) {
	    lastId = Action.NO_ID;
	}
	return result;
    }
}

package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IActionDAO;
import data.dao.db.DBActionDAO;

import data.model.Contre;

public class DBContreDao extends DBContreDao{

    public static final  String TABLE_NAME             = "CONTRE";
    

    private static final String ID_FIELD_NAME          = "ID";
    private static final String ACTION_ID_FIELD_NAME   = "ACTION_ID";
  
   
     
    private static final String ID_FIELD_TYPE          = "INTEGER";
    private static final String ACTION_ID_FIELD_TYPE   = "INTEGER";
    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + ACTION_ID_FIELD_NAME     + " " + ACTION_ID_FIELD_TYPE ;

    private PreparedStatement GET_ALL_CONTRES_PSTATEMENT    = null;
    private PreparedStatement GET_CONTRE_PSTATEMENT         = null;
    private PreparedStatement UPDATE_CONTRE_PSTATEMENT      = null;
    private PreparedStatement INSERT_CONTRE_PSTATEMENT      = null;
    private PreparedStatement DELETE_CONTRE_PSTATEMENT = null;

    private int lastId = Contre.NO_ID;

    
    public DBContreDAO(){}

    public Contre getContre(int i){
	Collection<Contre> contres=getContresWithIDFilter(id);
	Contre contre;
	if (contres.size() == 1) {
	    contre = contres.iterator().next();
	} else {
	    contre = null;
	}
	return contre;
    }


    private List<Contre> getContresWithIDFilter(Integer id) {
	if (GET_ALL_CONTRES_PSTATEMENT == null) {
	    
	    GET_ALL_CONTRES_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										      + TABLE_NAME 
										      + " order by "
										      + ID_FIELD_NAME);
	}
	if (GET_CONTRE_PSTATEMENT == null) {
	    GET_CONTRE_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										+ TABLE_NAME 
										+ " where "
										+ ID_FIELD_NAME 
										+ "=?" 
										+ " order by " 
										+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_CONTRE_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_CONTRES_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Contres", e);
	    resultSet = null;
	}
	
	List<Contre> result;
	if (resultSet == null) {
	    result = new ArrayList<Contre>();
	} else {
	    result = new ArrayList<Contre>();
	    try {
		while (resultSet.next()) {
		   Contre contre = new Contre();
		   contre.setId(resultSet.getInt(ID_FIELD_NAME));
		    contre.setActionId(resultSet.getInt(ACTION_ID_FIELD_NAME));		    	    
		    //en tant que action		   
		    result.add(contre);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }


    public List<Contre> getContres(){
	return getContresWithIDFilter(null);
    }

    public boolean addOrModify(Contre contre){
	super.addOrModify(contre);
	boolean result;
	
	// ajout
	contre.setId(getNextContreId());
	    
	try {
	    if (INSERT_CONTRE_PSTATEMENT == null) {
		//DBAction.super(getAction(actionId)); 
		INSERT_CONTRE_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										       + TABLE_NAME
										       + " ("
										       + ID_FIELD_NAME
										       + ", " 
										       + ACTION_ID_FIELD_NAME								                                                                                       + ") values (?, ?)");
	    } else {
		INSERT_CONTRE_PSTATEMENT.clearParameters();
	    }		
	    INSERT_CONTRE_PSTATEMENT.setInt(1, contre.getId());
	    INSERT_CONTRE_PSTATEMENT.setInt(2, contre.getActionId());
	

				
	    result = INSERT_CONTRE_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while inserting Contre", e);
	    result = false;
	}

	return result;
    }


    private int getNextContreId() {
	if (lastId == Contre.NO_ID) {
	    Collection<Contre> contres = getContres();
	    for (Iterator<Contre> contreIte = contres.iterator(); contreIte.hasNext();) {
		Contre contre = contreIte.next();
		if (contre.getId() > lastId) {
		    lastId = contre.getId();
		}
	    }
	}
	return ++lastId;
    }
    

    public boolean deleteAllContre(){
	if (DELETE_ALL_CONTRES_PSTATEMENT == null) {
	    DELETE_ALL_CONTRES_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_CONTRES_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Contres", e);
	    result = false;
	}
	if (result) {
	    lastId = Contre.NO_ID;
	}
	return result;
    }
}

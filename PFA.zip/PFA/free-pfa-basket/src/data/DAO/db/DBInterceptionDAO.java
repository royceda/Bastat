package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IActionDAO;
import data.dao.db.DBActionDAO;

import data.model.Interception;

public class DBInterceptionDao extends DBInterceptionDao{

    public static final  String TABLE_NAME             = "INTERCEPTION";
    

    private static final String ID_FIELD_NAME          = "ID";
    private static final String ACTION_ID_FIELD_NAME   = "ACTION_ID";
  
   
     
    private static final String ID_FIELD_TYPE          = "INTEGER";
    private static final String ACTION_ID_FIELD_TYPE   = "INTEGER";
    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + ACTION_ID_FIELD_NAME     + " " + ACTION_ID_FIELD_TYPE ;

    private PreparedStatement GET_ALL_INTERCEPTIONS_PSTATEMENT    = null;
    private PreparedStatement GET_INTERCEPTION_PSTATEMENT         = null;
    private PreparedStatement UPDATE_INTERCEPTION_PSTATEMENT      = null;
    private PreparedStatement INSERT_INTERCEPTION_PSTATEMENT      = null;
    private PreparedStatement DELETE_INTERCEPTION_PSTATEMENT = null;

    private int lastId = Interception.NO_ID;

    
    public DBInterceptionDAO(){}

    public Interception getInterception(int i){
	Collection<Interception> interceptions=getInterceptionsWithIDFilter(id);
	Interception interception;
	if (interceptions.size() == 1) {
	    interception = interceptions.iterator().next();
	} else {
	    interception = null;
	}
	return interception;
    }


    private List<Interception> getInterceptionsWithIDFilter(Integer id) {
	if (GET_ALL_INTERCEPTIONS_PSTATEMENT == null) {
	    
	    GET_ALL_INTERCEPTIONS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										      + TABLE_NAME 
										      + " order by "
										      + ID_FIELD_NAME);
	}
	if (GET_INTERCEPTION_PSTATEMENT == null) {
	    GET_INTERCEPTION_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
										+ TABLE_NAME 
										+ " where "
										+ ID_FIELD_NAME 
										+ "=?" 
										+ " order by " 
										+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_INTERCEPTION_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_INTERCEPTIONS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Interceptions", e);
	    resultSet = null;
	}
	
	List<Interception> result;
	if (resultSet == null) {
	    result = new ArrayList<Interception>();
	} else {
	    result = new ArrayList<Interception>();
	    try {
		while (resultSet.next()) {
		   Interception interception = new Interception();
		   interception.setId(resultSet.getInt(ID_FIELD_NAME));
		    interception.setActionId(resultSet.getInt(ACTION_ID_FIELD_NAME));		    	    
		    //en tant que action		   
		    result.add(interception);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }


    public List<Interception> getInterceptions(){
	return getInterceptionsWithIDFilter(null);
    }

    public boolean addOrModify(Interception interception){
	super.addOrModify(interception);
	boolean result;
	
	// ajout
	interception.setId(getNextInterceptionId());
	    
	try {
	    if (INSERT_INTERCEPTION_PSTATEMENT == null) {
		//DBAction.super(getAction(actionId)); 
		INSERT_INTERCEPTION_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										       + TABLE_NAME
										       + " ("
										       + ID_FIELD_NAME
										       + ", " 
										       + ACTION_ID_FIELD_NAME								                                                                                       + ") values (?, ?)");
	    } else {
		INSERT_INTERCEPTION_PSTATEMENT.clearParameters();
	    }		
	    INSERT_INTERCEPTION_PSTATEMENT.setInt(1, interception.getId());
	    INSERT_INTERCEPTION_PSTATEMENT.setInt(2, interception.getActionId());
	

				
	    result = INSERT_INTERCEPTION_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while inserting Interception", e);
	    result = false;
	}

	return result;
    }


    private int getNextInterceptionId() {
	if (lastId == Interception.NO_ID) {
	    Collection<Interception> interceptions = getInterceptions();
	    for (Iterator<Interception> interceptionIte = interceptions.iterator(); interceptionIte.hasNext();) {
		Interception interception = interceptionIte.next();
		if (interception.getId() > lastId) {
		    lastId = interception.getId();
		}
	    }
	}
	return ++lastId;
    }
    

    public boolean deleteAllInterception(){
	if (DELETE_ALL_INTERCEPTIONS_PSTATEMENT == null) {
	    DELETE_ALL_INTERCEPTIONS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_INTERCEPTIONS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Interceptions", e);
	    result = false;
	}
	if (result) {
	    lastId = Interception.NO_ID;
	}
	return result;
    }
}

package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IActionDAO;
import data.dao.db.DBActionDAO;

import data.model.Shoot;


public class DBShootDAO extends DBActionDAO{

    private static final Logger LOGGER = Logger.getLogger(DBShootDAO.class.getName());

    // private DBActionDAO DBAction;
    //a-un
    
    public static final  String TABLE_NAME             = "SHOOT";
    

    private static final String ID_FIELD_NAME          = "ID";
    private static final String ACTION_ID_FIELD_NAME   = "ACTION_ID";
    private static final String TYPE_FIELD_NAME        = "TYPE";
    private static final String REUSSI_FIELD_NAME      = "REUSSI";
   
     
    private static final String ID_FIELD_TYPE          = "INTEGER";
    private static final String ACTION_ID_FIELD_TYPE   = "INTEGER";
    private static final String TYPE_FIELD_TYPE        = "INTEGER";
    private static final String REUSSI_FIELD_TYPE      = "INTEGER";

       
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + ACTION_ID_FIELD_NAME     + " " + ACTION_ID_FIELD_TYPE 
	+ ", " + TYPE_FIELD_NAME    + " " + TYPE_FIELD_TYPE 
	+ ", " + REUSSI_FIELD_NAME  + " " + REUSSI_FIELD_TYPE ;

    
    private PreparedStatement GET_ALL_SHOOTS_PSTATEMENT    = null;
    private PreparedStatement GET_SHOOT_PSTATEMENT         = null;
    private PreparedStatement UPDATE_SHOOT_PSTATEMENT      = null;
    private PreparedStatement INSERT_SHOOT_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_SHOOTS_PSTATEMENT = null;
    
    private int lastId = Shoot.NO_ID;
   

    /*__________________Methodes_____________________*/

    public DBShootDAO(){}

   
    public Shoot getShoot(int id){ 
	Collection<Shoot> shoots = getShootsWithIDFilter(id);
	Shoot shoot;
	if (shoots.size() == 1) {
	    shoot = shoots.iterator().next();
	} else {
	    shoot = null;
	}
	return shoot;
    }
    
    
    private List<Shoot> getShootsWithIDFilter(Integer id) {
	if (GET_ALL_SHOOTS_PSTATEMENT == null) {
	    
	    GET_ALL_SHOOTS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									    + TABLE_NAME 
									    + " order by "
									    + ID_FIELD_NAME);
	}
	if (GET_SHOOT_PSTATEMENT == null) {
	    GET_SHOOT_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									+ TABLE_NAME 
									+ " where "
									+ ID_FIELD_NAME 
									+ "=?" 
									+ " order by " 
									+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_SHOOT_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_SHOOTS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Shoots", e);
	    resultSet = null;
	}
	
	List<Shoot> result;
	if (resultSet == null) {
	    result = new ArrayList<Shoot>();
	} else {
	    result = new ArrayList<Shoot>();
	    try {
		while (resultSet.next()) {
		    Shoot shoot = new Shoot();
		    shoot.setId(resultSet.getInt(ID_FIELD_NAME));
		    shoot.setActionId(resultSet.getInt(ACTION_ID_FIELD_NAME));
		    shoot.setType(resultSet.getInt(TYPE_FIELD_NAME));
		    shoot.setReussi(resultSet.getInt(REUSSI_FIELD_NAME));
		    //en tant que action
		   
		    result.add(shoot);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }
        
    public List<Shoot> getShoots(){
	return getShootsWithIDFilter(null);
    }
    

    public boolean addOrModify(Shoot shoot){
	super.addOrModify(shoot);
	boolean result;
	
	if (shoot.getId() > shoot.NO_ID) {
	    // modification
	    try {
		if (UPDATE_SHOOT_PSTATEMENT == null) {
		    UPDATE_SHOOT_PSTATEMENT = DBManager.INSTANCE.prepareStatement("UPDATE " 
										  + TABLE_NAME 
										  + " SET "
										  + TYPE_FIELD_NAME
										  + "=?, " 
										  + ACTION_ID_FIELD_NAME
										  + "=?"
										  + REUSSI_FIELD_NAME 
										  + "=?, "
										  + " where " 
										  + ID_FIELD_NAME 
										  + "=?");		   
		} else {
		    UPDATE_SHOOT_PSTATEMENT.clearParameters();
		}
		UPDATE_SHOOT_PSTATEMENT.setInt(1, shoot.getId());
		UPDATE_SHOOT_PSTATEMENT.setInt(2, shoot.getActionId());
		UPDATE_SHOOT_PSTATEMENT.setInt(3, shoot.getType());
		UPDATE_SHOOT_PSTATEMENT.setInt(4, shoot.getReussi());
	

		result = UPDATE_SHOOT_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while updating Shoot", e);
		result = false;
	    }
	   
	    
	} else {
	    // ajout
	    shoot.setId(getNextShootId());
	    
	    try {
		if (INSERT_SHOOT_PSTATEMENT == null) {
		    //DBAction.super(getAction(actionId)); 
		    INSERT_SHOOT_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										  + TABLE_NAME
										  + " ("
										  + ID_FIELD_NAME
										  + ", " 
										  + ACTION_ID_FIELD_NAME 
										  + ", " 
										  + TYPE_FIELD_NAME 
										  + ", "
										  + REUSSI_FIELD_NAME 
										  + ") values (?, ?, ?, ?)");
		} else {
		    INSERT_SHOOT_PSTATEMENT.clearParameters();
		}		
		INSERT_SHOOT_PSTATEMENT.setInt(1, shoot.getId());
		INSERT_SHOOT_PSTATEMENT.setInt(2, shoot.getActionId());
		INSERT_SHOOT_PSTATEMENT.setInt(3, shoot.getType());
		INSERT_SHOOT_PSTATEMENT.setInt(4, shoot.getReussi());

				
		result = INSERT_SHOOT_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while inserting Shoot", e);
		result = false;
	    }
	}
	return result;
    }
    
    private int getNextShootId() {
	if (lastId == Shoot.NO_ID) {
	    Collection<Shoot> shoots = getShoots();
	    for (Iterator<Shoot> shootIte = shoots.iterator(); shootIte.hasNext();) {
		Shoot shoot = shootIte.next();
		if (shoot.getId() > lastId) {
		    lastId = shoot.getId();
		}
	    }
	}
	return ++lastId;
    }
    
   
    //prochainement
    public List<Shoot> getShootsWithJoueurAndMatch(int idPlayer, int idMatch){
	List<Shoot> shoot = null;
	return shoot;
    } 



    public boolean deleteAllShoot(){
	if (DELETE_ALL_SHOOTS_PSTATEMENT == null) {
	    DELETE_ALL_SHOOTS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_SHOOTS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Shoots", e);
	    result = false;
	}
	if (result) {
	    lastId = Shoot.NO_ID;
	}
	return result;
    }
}

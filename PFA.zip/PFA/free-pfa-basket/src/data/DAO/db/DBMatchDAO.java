package src.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import src.data.dao.DBManager;
import src.data.dao.IMatchDAO;


import src.Match;


public class DBPlayerDAO implements IPlayerDAO{

    private static final Logger LOGGER = Logger.getLogger(DBPlayerDAO.class.getName());
    
    public static final String TABLE_NAME                    = "MATCH";
    
    private static final String ID_FIELD_NAME                = "ID";
    private static final String LIBELLE_FIELD_NAME           = "LIBELLE";
    private static final String DATE_FIELD_NAME              = "DATE";
    private static final String FORMATION1_FIELD_NAME        = "FORMATION1";
    private static final String FORMATION2_FIELD_NAME        = "FORMATION2";
    private static final String REGLE_FORMATION1_FIELD_NAME  = "REGLE_FORMATION1";
    private static final String REGLE_FORMATION2_FIELD_NAME  = "REGLE_FORMATION2";
    private static final String RESULTAT_FIELD_NAME          = "RESULTAT";
    private static final String SCORE1_FIELD_NAME            = "SCORE1";
    private static final String SCORE2_FIELD_NAME            = "SCORE2";
    private static final String ARBITRE1_ID_FIELD_NAME       = "ARBITRE1";
    private static final String ARBITRE2_ID_FIELD_NAME       = "ARBITRE2";
    private static final String PHASE_ID_FIELD_NAME          = "PHASE_ID";
    private static final String NIVEAU_STATS_NAME            = "NIVEAU_STATS";


    private static final String ID_FIELD_TYPE                = "ID";
    private static final String LIBELLE_FIELD_TYPE           = "TEXT";
    private static final String DATE_FIELD_TYPE              = "DATE";
    private static final String FORMATION1_FIELD_TYPE        = "INTEGER";
    private static final String FORMATION2_FIELD_TYPE        = "INTEGER";
    private static final String REGLE_FORMATION1_FIELD_TYPE  = "TEXT";
    private static final String REGLE_FORMATION2_FIELD_TYPE  = "TEXT";
    private static final String RESULTAT_FIELD_TYPE          = "INTEGER";
    private static final String SCORE1_FIELD_TYPE            = "INTEGER";
    private static final String SCORE2_FIELD_TYPE            = "INTEGER";
    private static final String ARBITRE1_ID_FIELD_TYPE       = "INTEGER";
    private static final String ARBITRE2_ID_FIELD_TYPE       = "INTEGER";
    private static final String PHASE_ID_FIELD_TYPE          = "INTEGER";
    private static final String NIVEAU_STATS_TYPE            = "INTEGER";

    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + LIBELLE_FIELD_NAME            + " " + LIBELLE_FIELD_TYPE 
	+ ", " + DATE_FIELD_NAME               + " " + DATE_FIELD_TYPE 
	+ ", " + FORMATION1_FIELD_NAME         + " " + FORMATION1_FIELD_TYPE 
	+ ", " + FORMATION2_FIELD_NAME         + " " + FORMATION2_FIELD_TYPE 
	+ ", " + REGLE_FORMATION1_FIELD_NAME   + " " + REGLE_FORMATION1_FIELD_TYPE 
	+ ", " + REGLE_FORMATION2_FIELD_NAME   + " " + REGLE_FORMATION2_FIELD_TYPE 
	+ ", " + RESULTAT_FIELD_NAME           + " " + RESULTAT_FIELD_TYPE 
	+ ", " + SCORE1_FIELD_NAME             + " " + SCORE1_FIELD_TYPE 
	+ ", " + SCORE2_FIELD_NAME             + " " + SCORE2_FIELD_TYPE 
	+ ", " + ARBITRE1_FIELD_NAME           + " " + ARBITRE1_FIELD_TYPE
	+ ", " + ARBITRE2_FIELD_NAME           + " " + ARBITRE2_FIELD_TYPE
	+ ", " + PHASE_ID_FIELD_NAME           + " " + PHASE_ID_FIELD_TYPE 
	+ ", " + NIVEAU_STATS_FIELD_NAME       + " " + NIVEAU_STATS_FIELD_TYPE ;
    
    private PreparedStatement GET_ALL_MATCHS_PSTATEMENT    = null;
    private PreparedStatement GET_MATCH_PSTATEMENT         = null;
    private PreparedStatement UPDATE_MATCH_PSTATEMENT      = null;
    private PreparedStatement INSERT_MATCH_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_MATCHS_PSTATEMENT = null;
    
    private int lastId = Match.NO_ID;
   

    /*__________________Methodes_____________________*/

    public DBMatchDAO{}


    public List<Match> getMatch(int id){ 
	Collection<Match> matchs = getMatchsWithIDFilter(id);
	Match match;
	if (matchss.size() == 1) {
	    match = matchs.iterator().next();
	} else {
	    match = null;
	}
	return match;
    }
    
    
    private List<Match> getMatchsWithIDFilter(Integer id) {
	if (GET_ALL_MATCHS_PSTATEMENT == null) {
	    GET_ALL_MATCHS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " + TABLE_NAME + " order by "
									     + ID_FIELD_NAME);
	}
	if (GET_MATCH_PSTATEMENT == null) {
	    GET_MATCH_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									+ TABLE_NAME 
									+ " where "
									+ ID_FIELD_NAME 
									+ "=?" 
									+ " order by " 
									+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_MATCH_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_MATCHS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Matchs", e);
	    resultSet = null;
	}
	
	List<Match> result;
	if (resultSet == null) {
	    result = new ArrayList<Match>();
	} else {
	    result = new ArrayList<Match>();
	    try {
		while (resultSet.next()) {
		    Match match = new Match();
		 
		    match.setId(resultSet.getInt(ID_FIELD_NAME));
		    match.setNom(resultSet.getString(LIBELLE_FIELD_NAME));
		    match.setNaissance(new Date(resultSet.getLong(DATE_FIELD_NAME)));
		    match.setPrenom(resultSet.getInt(FORMATION1_FIELD_NAME));
		    match.setPseudo(resultSet.getInt(FORMATION2_FIELD_NAME));
		    match.setPhoto(resultSet.getString(REGLE_FORMATION1_NAME));
		    match.setPhoto(resultSet.getString(REGLE_FORMATION2_NAME));
		    match.setSexe(resultSet.getInt(RESULTAT_FIELD_NAME));
		    match.setMdp(resultSet.getInt(SCORE1_FIELD_NAME));
		    match.setUtilisateur(resultSet.getInt(SCORE2_FIELD_NAME));
		    match.setDroit(resultSet.getInt(ARBITRE1_FIELD_NAME));
		    match.setDroit(resultSet.getInt(ARBITRE2_FIELD_NAME));
		    match.setDroit(resultSet.getInt(PHASE_ID_FIELD_NAME));
		    match.setDroit(resultSet.getInt(NIVEAU_STATS_FIELD_NAME));
		    
		    result.add(Match);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }
        
    public Match getMatchs(){
	return getMatchsWithIDFilter(null);
    }
    

    public boolean addOrModify(Match match){
	boolean result;
	
	if (match.getId() > match.NO_ID) {
	    // modification
	    try {
		if (UPDATE_MATCH_PSTATEMENT == null) {
		    UPDATE_MATCH_PSTATEMENT = DBManager.INSTANCE.prepareStatement("UPDATE " 
										  + TABLE_NAME 
										  + " SET "
										  + ID_FIELD_NAME 
										  + "=?, " 
										  + LIBELLE_FIELD_NAME
										  + "=?, " 
										  + FORMATION1_FIELD_NAME 
										  + "=?, "
										  + FORMATION2_FIELD_NAME 
										  + "=?, "
										  + REGLE_FORMATION1_FIELD_NAME
										  + "=?,"
										  + REGLE_FORMATION2_FIELD_NAME 
										  + "=?, " 
										  + DATE_FIELD_NAME
										  + "=?, " 
										  + RESULTAT_FIELD_NAME
										  + "=?, " 
										  + SCORE1_FIELD_NAME
										  + "=?, " 
										  + SCORE2_FIELD_NAME
										  + "=?, " 
										  + ARBITRE1_FIELD_NAME
										  + "=?," 
										  + ARBITRE2_FIELD_NAME
										  + "=?, " 
										  + PHASE_ID_FIELD_NAME
										  + "=?, " 
										  + NIVEAU_STATS_FIELD_NAME
										  + "=?, " 
										  + " where " 
										  + ID_FIELD_NAME 
										  + "=?");
		} else {
		    UPDATE_MATCH_PSTATEMENT.clearParameters();
		}
		UPDATE_MATCH_PSTATEMENT.setString(1, match.getId());
		UPDATE_MATCH_PSTATEMENT.setString(2, match.getLibelle());
		UPDATE_MATCH_PSTATEMENT.setString(3, match.getFormation1());
		UPDATE_MATCH_PSTATEMENT.setString(4, match.getFormation2());
		UPDATE_MATCH_PSTATEMENT.setLong(5,   match.getDate().getTime());
		UPDATE_MATCH_PSTATEMENT.setString(6, match.getRegleFormation1());
		UPDATE_MATCH_PSTATEMENT.setString(7, match.getRegleFormation2());
		UPDATE_MATCH_PSTATEMENT.setInt(8,    match.getResultat());
		UPDATE_MATCH_PSTATEMENT.setInt(9,    match.getScore1());
		UPDATE_MATCH_PSTATEMENT.setInt(10,   match.getScore2());
		UPDATE_MATCH_PSTATEMENT.setInt(11,   match.getArbitre1());
		UPDATE_MATCH_PSTATEMENT.setInt(12,   match.getArbitre2());
		UPDATE_MATCH_PSTATEMENT.setInt(13,   match.getPhaseId());
		UPDATE_MATCH_PSTATEMENT.setInt(14,   match.getNiveauStats());
		
		//UPDATE_MATCH_PSTATEMENT.setInt(6, match.getPriority());
		//UPDATE_MATCH_PSTATEMENT.setInt(7, (task.isDone() ? IS_MATCH_DONE : IS_MATCH_NOT_DONE));
		result = UPDATE_MATCH_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while updating Match", e);
		result = false;
	    }
	   
	    
	} else {
	    // ajout
	    match.setId(getNextMatchId());
	    
	    try {
		if (INSERT_MATCH_PSTATEMENT == null) {
		    INSERT_MATCH_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										  + TABLE_NAME +"(" 
										  + ID_FIELD_NAME 
										  + ", " 
										  + LIBELLE_FIELD_NAME
										  + ", " 
										  + FORMATION1_FIELD_NAME 
										  + ", "
										  + FORMATION2_FIELD_NAME 
										  + ", "
										  + REGLE_FORMATION1_FIELD_NAME
										  + ","
										  + REGLE_FORMATION2_FIELD_NAME 
										  + ", " 
										  + DATE_FIELD_NAME
										  + ", " 
										  + RESULTAT_FIELD_NAME
										  + ", " 
										  + SCORE1_FIELD_NAME
										  + ", " 
										  + SCORE2_FIELD_NAME
										  + ", " 
										  + ARBITRE1_FIELD_NAME
										  + "," 
										  + ARBITRE2_FIELD_NAME
										  + ", " 
										  + PHASE_ID_FIELD_NAME
										  + ", " 
										  + NIVEAU_STATS_FIELD_NAME
										  + ") values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
		} else {
		    INSERT_MATCH_PSTATEMENT.clearParameters();
		}		
		

		INSERT_MATCH_PSTATEMENT.setString(1, match.getId());
		INSERT_MATCH_PSTATEMENT.setString(2, match.getLibelle());
		INSERT_MATCH_PSTATEMENT.setString(3, match.getFormation1());
		INSERT_MATCH_PSTATEMENT.setString(4, match.getFormation2());
		INSERT_MATCH_PSTATEMENT.setLong(5,   match.getDate().getTime());
		INSERT_MATCH_PSTATEMENT.setString(6, match.getRegleFormation1());
		INSERT_MATCH_PSTATEMENT.setString(7, match.getRegleFormation2());
		INSERT_MATCH_PSTATEMENT.setInt(8,    match.getResultat());
		INSERT_MATCH_PSTATEMENT.setInt(9,    match.getScore1());
		INSERT_MATCH_PSTATEMENT.setInt(10,   match.getScore2());
		INSERT_MATCH_PSTATEMENT.setInt(11,   match.getArbitre1());
		INSERT_MATCH_PSTATEMENT.setInt(12,   match.getArbitre2());
		INSERT_MATCH_PSTATEMENT.setInt(13,   match.getPhaseId());
		INSERT_MATCH_PSTATEMENT.setInt(14,   match.getNiveauStats());
		

		
		//UPDATE_MATCH_PSTATEMENT.setInt(6, match.getPriority());
		//UPDATE_MATCH_PSTATEMENT.setInt(7, (task.isDone() ? IS_MATCH_DONE : IS_MATCH_NOT_DONE));
				
		result = INSERT_MATCH_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while inserting Match", e);
		result = false;
	    }
	}
	return result;
    }
    
    private int getNextMatchId() {
	if (lastId == Task.NO_ID) {
	    Collection<Task> matchs = getMatchs();
	    for (Iterator<Match> matchIte = matchs.iterator(); matchIte.hasNext();) {
		Task task = matchIte.next();
		if (match.getId() > lastId) {
		    lastId = task.getId();
		}
	    }
	}
	return ++lastId;
    }
    
   
    public boolean deleteAllMatch(){
	if (DELETE_ALL_MATCHS_PSTATEMENT == null) {
	    DELETE_ALL_MATCHS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_MATCHS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Matchs", e);
	    result = false;
	}
	if (result) {
	    lastId = Match.NO_ID;
	}
	return result;
    }
}

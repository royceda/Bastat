package data.dao.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.DBManager;
import data.dao.IJoueurDAO;
import data.model.Joueur;



public class DBJoueurDAO implements IJoueurDAO{

    private static final Logger LOGGER = Logger.getLogger(DBJoueurDAO.class.getName());
    
    public static final String TABLE_NAME              = "JOUEUR";
    
    private static final String ID_FIELD_NAME          = "ID";
    private static final String NOM_FIELD_NAME         = "NOM";
    private static final String PRENOM_FIELD_NAME      = "PRENOM";
    private static final String PSEUDO_FIELD_NAME      = "PSEUDO";
    private static final String NAISSANCE_FIELD_NAME   = "NAISSANCE";
    private static final String SEXE_FIELD_NAME        = "SEXE";
    private static final String PHOTO_FIELD_NAME       = "PHOTO";
    private static final String UTILISATEUR_FIELD_NAME = "NOM_UTILISATEUR";
    private static final String MDP_FIELD_NAME         = "MD5_MDP";
    private static final String DROITS_FIELD_NAME      = "DROITS";
    
    
    private static final String ID_FIELD_TYPE          = "INTEGER";
    private static final String NOM_FIELD_TYPE         = "TEXT";
    private static final String PRENOM_FIELD_TYPE      = "TEXT";
    private static final String PSEUDO_FIELD_TYPE      = "TEXT";
    private static final String NAISSANCE_FIELD_TYPE   = "INTEGER"; //DATE
    private static final String SEXE_FIELD_TYPE        = "TEXT"; 
    private static final String PHOTO_FIELD_TYPE       = "TEXT";
    private static final String UTILISATEUR_FIELD_TYPE = "TEXT"; 
    private static final String MDP_FIELD_TYPE         = "TEXT";
    private static final String DROITS_FIELD_TYPE      = "INTEGER"; 
    

    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + NOM_FIELD_NAME         + " " + NOM_FIELD_TYPE 
	+ ", " + PRENOM_FIELD_NAME      + " " + PRENOM_FIELD_TYPE 
	+ ", " + PSEUDO_FIELD_NAME      + " " + PSEUDO_FIELD_TYPE 
	+ ", " + NAISSANCE_FIELD_NAME   + " " + NAISSANCE_FIELD_TYPE 
	+ ", " + SEXE_FIELD_NAME        + " " + SEXE_FIELD_TYPE 
	+ ", " + PHOTO_FIELD_NAME       + " " + PHOTO_FIELD_TYPE 
	+ ", " + UTILISATEUR_FIELD_NAME + " " + UTILISATEUR_FIELD_TYPE 
	+ ", " + MDP_FIELD_NAME         + " " + MDP_FIELD_TYPE
	+ ", " + DROITS_FIELD_NAME      + " " + DROITS_FIELD_TYPE;
    
    private PreparedStatement GET_ALL_JOUEURS_PSTATEMENT    = null;
    private PreparedStatement GET_JOUEUR_PSTATEMENT         = null;
    private PreparedStatement UPDATE_JOUEUR_PSTATEMENT      = null;
    private PreparedStatement INSERT_JOUEUR_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_JOUEURS_PSTATEMENT = null;
    
    private int lastId = Joueur.NO_ID;
   

    /*__________________Methodes_____________________*/

    public DBJoueurDAO(){
    }


    public Joueur getJoueur(int id){ 
	Collection<Joueur> joueurs = getJoueursWithIDFilter(id);
	Joueur joueur;
	if (joueurs.size() == 1) {
	    joueur = joueurs.iterator().next();
	} else {
	    joueur = null;
	}
	return joueur;
    }
    
    
    private List<Joueur> getJoueursWithIDFilter(Integer id) {
	if (GET_ALL_JOUEURS_PSTATEMENT == null) {
	    GET_ALL_JOUEURS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									     + TABLE_NAME 
									     + " order by "
									     + ID_FIELD_NAME);
	}
	if (GET_JOUEUR_PSTATEMENT == null) {
	    GET_JOUEUR_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									+ TABLE_NAME 
									+ " where "
									+ ID_FIELD_NAME 
									+ "=?" 
									+ " order by " 
									+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_JOUEUR_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_JOUEURS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Joueurs", e);
	    resultSet = null;
	}
	
	List<Joueur> result;
	if (resultSet == null) {
	    result = new ArrayList<Joueur>();
	} else {
	    result = new ArrayList<Joueur>();
	    try {
		while (resultSet.next()) {
		    Joueur joueur = new Joueur();
		    joueur.setId(resultSet.getInt(ID_FIELD_NAME));
		    joueur.setNom(resultSet.getString(NOM_FIELD_NAME));
		    joueur.setPrenom(resultSet.getString(PRENOM_FIELD_NAME));
		    joueur.setPseudo(resultSet.getString(PSEUDO_FIELD_NAME));
		    joueur.setPhoto(resultSet.getString(PHOTO_FIELD_NAME));
		    joueur.setNaissance(new Date(resultSet.getLong(NAISSANCE_FIELD_NAME)));
		    joueur.setSexe(resultSet.getBoolean(SEXE_FIELD_NAME));
		    joueur.setMdp(resultSet.getString(MDP_FIELD_NAME));
		    joueur.setNomUtilisateur(resultSet.getString(UTILISATEUR_FIELD_NAME));
		    joueur.setDroits(resultSet.getInt(DROITS_FIELD_NAME));
		    		    
		    result.add(joueur);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }
        
    public List<Joueur> getJoueurs(){
	return getJoueursWithIDFilter(null);
    }
    

    public boolean addOrModify(Joueur joueur){
	boolean result = true;
	
	if (joueur.getId() > joueur.NO_ID) {
	    // modification
	    try {
		if (UPDATE_JOUEUR_PSTATEMENT == null) {
		    UPDATE_JOUEUR_PSTATEMENT = DBManager.INSTANCE.prepareStatement("UPDATE " 
										   + TABLE_NAME 
										   + " SET "
										   + NOM_FIELD_NAME 
										   + "=?, " 
										   + PRENOM_FIELD_NAME
										   + "=?, " 
										   + PSEUDO_FIELD_NAME 
										   + "=?, "
										   + NAISSANCE_FIELD_NAME 
										   + "=?, "
										   + UTILISATEUR_FIELD_NAME
										   + "=?,"
										   + PHOTO_FIELD_NAME 
										   + "=?, " 
										   + MDP_FIELD_NAME
										   + "=?, " 
										   + DROITS_FIELD_NAME
										   + "=?" 
										   + " where " 
										   + ID_FIELD_NAME 
										   + "=?");
		} else {
		    UPDATE_JOUEUR_PSTATEMENT.clearParameters();
		}
		UPDATE_JOUEUR_PSTATEMENT.setString(1, joueur.getNom());
		UPDATE_JOUEUR_PSTATEMENT.setString(2, joueur.getPrenom());
		UPDATE_JOUEUR_PSTATEMENT.setString(3, joueur.getPseudo());
		UPDATE_JOUEUR_PSTATEMENT.setString(4, joueur.getPhoto());
		UPDATE_JOUEUR_PSTATEMENT.setLong(5,   joueur.getNaissance().getTime());
		UPDATE_JOUEUR_PSTATEMENT.setString(6, joueur.getNomUtilisateur());
		UPDATE_JOUEUR_PSTATEMENT.setString(7, joueur.getMdp());
		UPDATE_JOUEUR_PSTATEMENT.setInt(8,    joueur.getDroits());
		UPDATE_JOUEUR_PSTATEMENT.setInt(9,    joueur.getId());
		
	
		result = UPDATE_JOUEUR_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while updating Joueur", e);
		result = false;
	    }
	   
	    
	} else {
	    // ajout
	    joueur.setId(getNextJoueurId());
	    
	    try {
		if (INSERT_JOUEUR_PSTATEMENT == null) {
		    INSERT_JOUEUR_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										 + TABLE_NAME + " ("
										 + ID_FIELD_NAME + ", " 
										 + NOM_FIELD_NAME 
										 + ", " 
										 + PRENOM_FIELD_NAME 
										 + ", "
										 + PSEUDO_FIELD_NAME 
										 + ", " 
										 + NAISSANCE_FIELD_NAME 
										 + ", " 
										 + PHOTO_FIELD_NAME 
										 + ", "
										 + UTILISATEUR_FIELD_NAME
										 + ", " 
										 + MDP_FIELD_NAME
										 + ", " 
										 + DROITS_FIELD_NAME
										 + ") values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
		} else {
		    INSERT_JOUEUR_PSTATEMENT.clearParameters();
		}		
		INSERT_JOUEUR_PSTATEMENT.setString(1, joueur.getNom());
		INSERT_JOUEUR_PSTATEMENT.setString(2, joueur.getPrenom());
		INSERT_JOUEUR_PSTATEMENT.setString(3, joueur.getPseudo());
		INSERT_JOUEUR_PSTATEMENT.setString(4, joueur.getPhoto());
		INSERT_JOUEUR_PSTATEMENT.setLong(5,   joueur.getNaissance().getTime());
		INSERT_JOUEUR_PSTATEMENT.setString(6, joueur.getNomUtilisateur());
		INSERT_JOUEUR_PSTATEMENT.setString(7, joueur.getMdp());
		INSERT_JOUEUR_PSTATEMENT.setInt(8, joueur.getDroits());
		INSERT_JOUEUR_PSTATEMENT.setInt(9,    joueur.getId());
		
		
				
		result = INSERT_JOUEUR_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while inserting Joueur", e);
		result = false;
	    }
	}
	return result;
    }
    
    private int getNextJoueurId() {
	if (lastId == Joueur.NO_ID) {
	    Collection<Joueur> joueurs = getJoueurs();
	    for (Iterator<Joueur> joueurIte = joueurs.iterator(); joueurIte.hasNext();) {
		Joueur joueur = joueurIte.next();
		if (joueur.getId() > lastId) {
		    lastId = joueur.getId();
		}
	    }
	}
	return ++lastId;
    }
    
   
    public boolean deleteAllJoueur(){
	if (DELETE_ALL_JOUEURS_PSTATEMENT == null) {
	    DELETE_ALL_JOUEURS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM " 
										+ TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_JOUEURS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Joueurs", e);
	    result = false;
	}
	if (result) {
	    lastId = Joueur.NO_ID;
	}
	return result;
    }
}

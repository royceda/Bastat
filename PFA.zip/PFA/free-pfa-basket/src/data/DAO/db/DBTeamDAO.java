package src.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


import src.data.dao.DBManager;
import src.data.dao.IEquipeAO;


import src.Team;


public class DBTeamDAO implements ITeamDAO{

    private static final Logger LOGGER = Logger.getLogger(DBPlayerDAO.class.getName());
    
    public static final String TABLE_NAME               = "EQUIPE";
    
    private static final String ID_FIELD_NAME           = "ID";
    private static final String COULEUR_BASE_FIELD_NAME = "COULEUR_BASE";
    private static final String PHOTO_FIELD_NAME        = "PHOTO";
    private static final String NOM_FIELD_NAME          = "NOM";
   


    private static final String ID_FIELD_TYPE           = "ID";
    private static final String COULEUR_BASE_FIELD_TYPE = "TEXT";
    private static final String PHOTO_FIELD_TYPE        = "TEXT";
    private static final String NOM_FIELD_TYPE          = "TEXT";


    
    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE 
	+ ", " + COULEUR_BASE_FIELD_NAME + " " + COULEUR_BASE_FIELD_TYPE 
	+ ", " + PHOTO_FIELD_NAME        + " " + PHOTO_FIELD_TYPE 
	+ ", " + NOM_FIELD_NAME          + " " + NOM_FIELD_TYPE ;


    
    private PreparedStatement GET_ALL_TEAMS_PSTATEMENT    = null;
    private PreparedStatement GET_TEAM_PSTATEMENT         = null;
    private PreparedStatement UPDATE_TEAM_PSTATEMENT      = null;
    private PreparedStatement INSERT_TEAM_PSTATEMENT      = null;
    private PreparedStatement DELETE_ALL_TEAMS_PSTATEMENT = null;
    
    private int lastId = Team.NO_ID;
   

    /*__________________Methodes_____________________*/

    public DBTeamDAO{}


    public List<Team> getTeam(int id){ 
	Collection<Team> teams = getTeamsWithIDFilter(id);
	Team team;
	if (teams.size() == 1) {
	    team = teams.iterator().next();
	} else {
	    team = null;
	}
	return team;
    }
    
    
    private List<Team> getTeamsWithIDFilter(Integer id) {
	if (GET_ALL_TEAMS_PSTATEMENT == null) {
	    GET_ALL_TEAMS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									   + TABLE_NAME + " order by "
									   + ID_FIELD_NAME);
	}
	if (GET_TEAM_PSTATEMENT == null) {
	    GET_TEAM_PSTATEMENT = DBManager.INSTANCE.prepareStatement("SELECT * from " 
									+ TABLE_NAME 
									+ " where "
									+ ID_FIELD_NAME 
									+ "=?" 
									+ " order by " 
									+ ID_FIELD_NAME);
	}
	
	ResultSet resultSet;
	try {
	    PreparedStatement pStatement;
	    if (id != null) {
		pStatement = GET_TEAM_PSTATEMENT;
		pStatement.setInt(1, id);
		
	    } else {
		pStatement = GET_ALL_TEAMS_PSTATEMENT;
	    }
	    
	    resultSet = pStatement.executeQuery();
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting Teams", e);
	    resultSet = null;
	}
	
	List<Team> result;
	if (resultSet == null) {
	    result = new ArrayList<Team>();
	} else {
	    result = new ArrayList<Team>();
	    try {
		while (resultSet.next()) {
		    Team team = new Team();
		 
		    team.setId(resultSet.getInt(ID_FIELD_NAME));
		    team.setNom(resultSet.getString(COULEUR_BASE_FIELD_NAME));		   
		    team.setPrenom(resultSet.getInt(PHOTO_FIELD_NAME));
		    team.setPseudo(resultSet.getInt(NOM_FIELD_NAME));
		   		    
		    result.add(Team);
		}
	    } catch (SQLException e) {
		e.printStackTrace();
		result = null;
	    }
	}
	
	return result; 
    }
        
    public Team getTeams(){
	return getTeamsWithIDFilter(null);
    }
    

    public boolean addOrModify(Team team){
	boolean result;
	
	if (team.getId() > team.NO_ID) {
	    // modification
	    try {
		if (UPDATE_TEAM_PSTATEMENT == null) {
		    UPDATE_TEAM_PSTATEMENT = DBManager.INSTANCE.prepareStatement("UPDATE " 
										 + TABLE_NAME 
										 + " SET "
										 + ID_FIELD_NAME 
										 + "=?, " 
										 + COULEUR_BASE_FIELD_NAME
										 + "=?, " 
										 + PHOTO_FIELD_NAME 
										 + "=?, "
										 + NOM_FIELD_NAME 
										 + "=?, "
										 + " where " 
										 + ID_FIELD_NAME 
										 + "=?");
		} else {
		    UPDATE_TEAM_PSTATEMENT.clearParameters();
		}
		UPDATE_TEAM_PSTATEMENT.setString(1, team.getId());
		UPDATE_TEAM_PSTATEMENT.setString(2, team.getCouleurBase());
		UPDATE_TEAM_PSTATEMENT.setString(3, team.getPhoto());
		UPDATE_TEAM_PSTATEMENT.setString(4, team.getNom());
		
		result = UPDATE_TEAM_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while updating Team", e);
		result = false;
	    }
	   
	    
	} else {
	    // ajout
	    team.setId(getNextTeamId());
	    
	    try {
		if (INSERT_TEAM_PSTATEMENT == null) {
		    INSERT_TEAM_PSTATEMENT = DBManager.INSTANCE.prepareStatement("INSERT INTO " 
										  + TABLE_NAME +"(" 
										  + ID_FIELD_NAME 
										  + ", " 
										  + COULEUR_BASE_FIELD_NAME
										  + ", " 
										  + PHOTO_FIELD_NAME 
										  + ", "
										  + NOM_FIELD_NAME 
										 + ") values (?, ?, ?, ?)");
		} else {
		    INSERT_TEAM_PSTATEMENT.clearParameters();
		}		
		

		UPDATE_TEAM_PSTATEMENT.setString(1, team.getId());
		UPDATE_TEAM_PSTATEMENT.setString(2, team.getCouleurBase());
		UPDATE_TEAM_PSTATEMENT.setString(3, team.getPhoto());
		UPDATE_TEAM_PSTATEMENT.setString(4, team.getNom());
					
		result = INSERT_TEAM_PSTATEMENT.executeUpdate() >= 1;
	    } catch (SQLException e) {
		LOGGER.log(Level.SEVERE, "Error while inserting Team", e);
		result = false;
	    }
	}
	return result;
    }
    
    private int getNextTeamId() {
	if (lastId == Task.NO_ID) {
	    Collection<Task> teams = getTeams();
	    for (Iterator<Team> teamIte = teams.iterator(); teamIte.hasNext();) {
		Task task = teamIte.next();
		if (team.getId() > lastId) {
		    lastId = task.getId();
		}
	    }
	}
	return ++lastId;
    }
    
   
    public boolean deleteAllTeam(){
	if (DELETE_ALL_TEAMS_PSTATEMENT == null) {
	    DELETE_ALL_TEAMS_PSTATEMENT = DBManager.INSTANCE.prepareStatement("DELETE FROM "
									      + TABLE_NAME);
	}
	boolean result;
	try {
	    result = DELETE_ALL_TEAMS_PSTATEMENT.executeUpdate() >= 1;
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while deleting all Teams", e);
	    result = false;
	}
	if (result) {
	    lastId = Team.NO_ID;
	}

	return result;
    }
}

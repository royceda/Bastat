package data.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

import java.util.logging.Logger;

import data.dao.IJoueurDAO;
import data.dao.IActionDAO;

import data.dao.db.DBJoueurDAO;
import data.dao.db.DBActionDAO;
import data.dao.db.DBShootDAO;
//import data.dao.db.DBMatchDAO;



public class DBManagerAndroid extends SQLiteOpenHelper {

    public  static DBManager INSTANCE = new DBManager();
    
    private IJoueurDAO playerDAO = null; 
    private IActionDAO actionDAO = null;
    private DBShootDAO shootDAO  = null;

  
    public DBManagerAndroid(Context context, String name, CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    public IJoueurDAO getJoueurDAO() {	
	if (playerDAO == null) {
	    playerDAO = new DBJoueurDAO();
	}
	return playerDAO;
    }
    
    public IActionDAO getActionDAO(){
	if(actionDAO == null){
	    actionDAO = new DBActionDAO();
	}
	return actionDAO;
    }
    
    public DBShootDAO getShootDAO(){
	if(shootDAO == null){
	    shootDAO = new DBShootDAO();
	}
	return shootDAO;
    }
    
    //a modifier
    public ResultSet executeQuery(String query) {
	Statement statement = null;
	ResultSet resultSet = null;
	try {
	    statement = connection.createStatement();
	    resultSet = statement.executeQuery(query);
	    
	    resultSet = db.query(query);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while executing query", e);
	    resultSet = null;
	} finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    } catch (Exception e) {
		e.printStackTrace();
		resultSet = null;
	    }
	}
	return resultSet;
    }

    //a modifier
    public boolean executeUpdate(String query) {
	Statement statement = null;
	int result;
	try {
	    statement = connection.createStatement();
	    result = statement.executeUpdate(query);

	    result = db.exec(query);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while executing update", e);
	    result = -1;
	} finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
		
	    } catch (Exception e) {
		e.printStackTrace();
		result = -1;
	    }
	}
	return result > 0;
    }
    
    //a modifier
    public PreparedStatement prepareStatement(String statement) {
	PreparedStatement pStatement;
	try {
	    pStatement = connection.prepareStatement(statement);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while preparing statement", e);
	    pStatement = null;
	}
	return pStatement;
    }

    

    @Override
    public void onCreate(SQLiteDatabase db) {
        //on cr�� la table � partir de la requ�te �crite dans la variable CREATE_BDD
	try{ db.execSQL("CREATE TABLE IF NOT EXISTS " 
		   + DBJoueurDAO.TABLE_NAME + " ("
		   + DBJoueurDAO.CREATE_TABLE_STATEMENT + ")");


	db.execSQL("CREATE TABLE IF NOT EXISTS " 
		   + DBShootDAO.TABLE_NAME + " ("
		   + DBShootDAO.CREATE_TABLE_STATEMENT + ")");
	
	db.execSQL("CREATE TABLE IF NOT EXISTS " 
		   + DBActionDAO.TABLE_NAME + " ("
		   + DBActionDAO.CREATE_TABLE_STATEMENT + ")");	   
	}catch("exception "){
	    LOGGER.log(Level.SEVERE, "Error while getting connexion", e);
	    connection = null;
	}catch("exception2"){
	    LOGGER.log(Level.SEVERE, "Error while getting connexion", e);
	    connection = null;
	}
	LOGGER.log(Level.INFO, "Assuming " + log + " context");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //On peut fait ce qu'on veut ici moi j'ai d�cid� de supprimer la table et de la recr�er
        //comme �a lorsque je change la version les id repartent de 0
        db.execSQL("DROP TABLE " + TABLE_LIVRES + ";");
        onCreate(db);
    }
}

package data.dao;

import java.util.List;
import data.model.Joueur;


public interface IJoueurDAO {

    public List<Joueur> getJoueurs();
    public Joueur getJoueur(int id);
    public boolean addOrModify(Joueur Joueur);
    public boolean deleteAllJoueur();
}

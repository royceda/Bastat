package data.dao;

import java.util.List;
import data.dao.model.Match;

public interface IMatchDAO {

    public List<Match> getMatchs();
    public List<Match> getMatchs(int idPlayer);
    public Player getMatch(int id);
    public boolean addorModify(Match Match);
    public boolean deleteAllMatch();
}

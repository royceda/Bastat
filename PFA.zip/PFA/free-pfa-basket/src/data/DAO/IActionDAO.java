package data.dao;

import java.util.List;
import data.model.Action;
import data.model.Joueur;

public interface IActionDAO {

    public List<Action> getActions();
    // public List<Action> getActions(int idPlayer, int idMatch); //Prochainement
    public Action getAction(int id);
    public boolean addOrModify(Action Action);
    public boolean deleteAllAction();
}

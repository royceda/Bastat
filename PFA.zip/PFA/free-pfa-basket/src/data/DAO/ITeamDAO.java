package data.dao;

import java.util.List;

public interface ITeamDAO {

    public List<Team> getTeams();
    public Team getTeam(int id);
    public boolean addorModify(Team Team);
    public boolean deleteAllTeam();
}

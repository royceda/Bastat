package data.dao;

import java.util.List;
import data.dao.model.Formation;


public interface IMatchDAO {

    public List<Formation> getFormations();
    public List<Formation> getFormations(int id);
    public Player getFormation(int id);
    public boolean addorModify(Formation Formation);
    public boolean deleteAllFormation();
}

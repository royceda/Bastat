package com.example.jean.basketstat;

import android.app.Activity;
import android.os.Bundle;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Jean on 19/01/15.
 */
public class Table extends Activity {

    final ArrayList<String> equipes = new ArrayList<String>();
    final ArrayList<String> joueurs = new ArrayList<String>();

    public void fillDataTable() {
        equipes.add("equipe1");
        equipes.add("equipe2");
        joueurs.add("alfred");
        joueurs.add("georges");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tabletest);
        fillDataTable();
        fillWithData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void fillWithData() {
        TableLayout table = (TableLayout)Table.this.findViewById(R.id.tableLay);
        for(int i=0 ; i<equipes.size(); i++)
        {
            TableRow row = new TableRow(this);
            String eq_name = equipes.get(i);
            String jo_name = joueurs.get(i);
                //(TableRow) LayoutInflater.from(Table.this).inflate(R.layout.tabletest, null);
            //((TextView)row.findViewById(R.id.nom_equipe)).setText(equipes.get(i));
            //((TextView)row.findViewById(R.id.nom_joueur)).setText(joueurs.get(i));
            TextView eq = new TextView(this);
            eq.setText(eq_name);
            TextView jo = new TextView(this);
            jo.setText(jo_name);
            row.addView(eq);
            row.addView(jo);
            table.addView(row);
        }
        table.requestLayout();     // Not sure if this is needed.
    }
}

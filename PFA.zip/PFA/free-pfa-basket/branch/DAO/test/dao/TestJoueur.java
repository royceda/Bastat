import data.mediator.DBMediator;
import data.dao.DBManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.model.Joueur;
import java.util.Date;
import java.util.List;

public class TestJoueur{


    TestJoueur(){
    }

    public static void main(String[] args){
	
	Date   N1 = new Date();
	Joueur J1 = new Joueur("Brown", "Charlie", "Peanuts", N1, true, "", "Snoopy", "", 1);
	J1.setId(12);
	Joueur J2 = new Joueur("Shakur", "Tupac", "2Pac", N1, true, "", "California", "", 2);
	Joueur J3 = new Joueur("Zouad", "Lotfi", "Musclor", N1, true, "", "Muscl'EIRB", "", 2);
	System.out.println("Instanciation:\t OK");
	


	try{
	    Class.forName("org.sqlite.JDBC");
	    System.out.println("Driver:\t\t OK");
	    Connection c = DriverManager.getConnection("jdbc:sqlite:test.sqlite");
	    System.out.println("DB:\t\t OK");
	    c.setAutoCommit(true);	
	    Statement stmt = null;
	    stmt = c.createStatement();
	}catch ( Exception e ) {
	    System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	    System.exit(0);
	}
	System.out.println("DataBase:\t OK");


	DBManager DB = new DBManager();
	System.out.println("DBManager:\t OK"); // mettre le constructeur en public avant

	DBMediator.addOrModifyJoueur(J1);
	DBMediator.addOrModifyJoueur(J2);
	DBMediator.addOrModifyJoueur(J3);
	System.out.println("Ajout:\t\t OK");
	

	Joueur J777 = DBMediator.getJoueur(12);//a finir
	System.out.println("Get:\t\t OK");
	/*
	DBMediator.deleteAllJoueur();  
	System.out.println("Delete:\t\t OK");
	*/
    }
}

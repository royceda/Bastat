package data.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


import data.dao.IJoueurDAO;
import data.dao.IActionDAO;

import data.dao.db.DBJoueurDAO;
import data.dao.db.DBActionDAO;
import data.dao.db.DBShootDAO;
//import data.dao.db.DBMatchDAO;

public class DBManager {
    private static final Logger    LOGGER   = Logger.getLogger(DBManager.class.getName());    
    public  static       DBManager INSTANCE = new DBManager();
    
    private boolean    isGoogleAppEngine;
    private Connection connection;


    private IJoueurDAO playerDAO = null; 
    private IActionDAO actionDAO = null;
    private DBShootDAO shootDAO  = null;
    // private IMatchDAO  matchDAO  = null;
  
    public DBManager() {
	//String sPathToDB = WebAppInitializer.ROOT + "db/Base.sqlite";
	String log;

	isGoogleAppEngine = false;
	log = "SQlite";
	try {	    
	    Class.forName("org.sqlite.JDBC");
	    connection = DriverManager.getConnection("jdbc:sqlite:Base.sqlite");
	    connection.setAutoCommit(true);
	    
	    /*______________________Creation des Tables____________________________*/
	    
	    executeUpdate("CREATE TABLE IF NOT EXISTS " + DBJoueurDAO.TABLE_NAME + " ("
			  + DBJoueurDAO.CREATE_TABLE_STATEMENT + ")");

	    executeUpdate("CREATE TABLE IF NOT EXISTS " + DBShootDAO.TABLE_NAME + " ("
			  + DBShootDAO.CREATE_TABLE_STATEMENT + ")");
	    
	    executeUpdate("CREATE TABLE IF NOT EXISTS " + DBActionDAO.TABLE_NAME + " ("
			  + DBActionDAO.CREATE_TABLE_STATEMENT + ")");
	    

	    /*
	      executeUpdate("CREATE TABLE IF NOT EXISTS " + DBMatchDAO.TABLE_NAME + " ("
			  + DBMatchDAO.CREATE_TABLE_STATEMENT + ")");
	    */

	    

	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting connexion", e);
	    connection = null;
	} catch (ClassNotFoundException e) {
	    LOGGER.log(Level.SEVERE, "Error while getting connexion", e);
	    connection = null;
	}
		
	LOGGER.log(Level.INFO, "Assuming " + log + " context");
    }



    /*_____________________________________*/


    
    public IJoueurDAO getJoueurDAO() {	
	if (playerDAO == null) {
	    playerDAO = new DBJoueurDAO();
	}
	return playerDAO;
    }
    
    public IActionDAO getActionDAO(){
	if(actionDAO == null){
	    actionDAO = new DBActionDAO();
	}
	return actionDAO;
    }

    public DBShootDAO getShootDAO(){
	if(shootDAO == null){
	    shootDAO = new DBShootDAO();
	}
	return shootDAO;
    }
    

    /*
    public IMatchDAO getMatchDAO(){
	if(matchDAO == null)
	    matchDAO = new DBMatchDAO();
    }
    */
    /*_____________________________________*/


    public ResultSet executeQuery(String query) {
	Statement statement = null;
	ResultSet resultSet = null;
	try {
	    statement = connection.createStatement();
	    resultSet = statement.executeQuery(query);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while executing query", e);
	    resultSet = null;
	} finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    } catch (Exception e) {
		e.printStackTrace();
		resultSet = null;
	    }
	}
	return resultSet;
    }
    

    public boolean executeUpdate(String query) {
	Statement statement = null;
	int result;
	try {
	    statement = connection.createStatement();
	    result = statement.executeUpdate(query);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while executing update", e);
	    result = -1;
	} finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
		
	    } catch (Exception e) {
		e.printStackTrace();
		result = -1;
	    }
	}
	return result > 0;
    }
    

    public PreparedStatement prepareStatement(String statement) {
	PreparedStatement pStatement;
	try {
	    pStatement = connection.prepareStatement(statement);
	} catch (SQLException e) {
	    LOGGER.log(Level.SEVERE, "Error while preparing statement", e);
	    pStatement = null;
	}
	return pStatement;
    }
    
}

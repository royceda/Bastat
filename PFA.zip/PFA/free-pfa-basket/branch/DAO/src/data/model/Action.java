package data.model;

import data.model.Joueur;

public class Action {

    public static int NO_ID = -1;
	
    public  int        id;
    private int        tempsDeJeu;
    private int        temps; //en seconde (hypothese simplificatrice)
    private int        joueurActeur;
    private int        joueurCible;
    private String     commentaire;
    private int        type;
    private int        specifique;
    
    //constructor
    
    public Action() {
	
    }
    

    public Action(Action a){
	//code
    }


    public Action(int temps, Joueur acteur, Joueur cible, String coment, int type, int specifique) {
	this.temps = temps;
	this.joueurActeur = acteur.getId();
	this.joueurCible = cible.getId();
    }
    
    public Action(int temps, int acteur, int cible, String coment, int type, int specifique) {
	this.temps = temps;
	this.joueurActeur = acteur;
	this.joueurCible = cible;
    }
    

    //getter
    public int getId(){
	return id;
    }

    public int getType(){
	return type;
    }

    public int getSpecifique(){
	return specifique;
    }

    public int getTemps() {
	return this.temps;
    }
    
    public int getTempsDeJeu() {
	return this.tempsDeJeu;
    }
    /*
    public Joueur getJoueurActeur() {
	return this.joueurActeur;
    }
    
    public Joueur getJoueurCible() {
	return this.joueurCible;
    }
    */

    public int getJoueurActeurId() {
	return this.joueurActeur;
    }
    
    public int getJoueurCibleId() {
	return this.joueurCible;
    }
    
    public String getCommentaire() {
	return this.commentaire;
    }
    
    //setters
    public void setId(int i){
	id = i;
    }
    
    public void setTemps(int temps) {
	this.temps = temps;
    }

    
    public void setJoueurActeur(int acteur) {
	this.joueurActeur = acteur;
    }
    
    public void setJoueurCible(int cible) {
	this.joueurCible = cible;
    }

    
    public void setJoueurActeur(Joueur acteur) {
	this.joueurActeur = acteur.getId();
    }
    
    public void setJoueurCible(Joueur cible) {
	this.joueurCible = cible.getId();
    }
    
    public void setCommentaire(String comment) {
	this.commentaire = comment;
    }

    
    /*  public void setId(int i){
	id = i;
    }
    */
    public void setType(int i){
	type = i;
    }
    
    public void setSpecifique(int s){
	specifique = s;
    }
    
    public void setTempsDeJeu(int t) {
	this.tempsDeJeu = t;
    }


}


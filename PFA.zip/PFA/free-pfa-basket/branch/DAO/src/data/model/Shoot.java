package data.model;

import data.model.Action;


public class Shoot extends Action{

    public static int NO_ID = -1;

    private int     id;
    private int     actionId;
    private int     type;
    private int     reussi;
    
    //Les constructor
    public Shoot(){
	super();
    }
    
   public Shoot(int id, int actionId, int type, int reussi){
       super();
       this.id       = id;
       this.type     = type;
       this.reussi   = reussi;
   }
    
    public Shoot(Action a){
	super(a);
    }

    public Shoot(Action a, Joueur ja, Joueur jc, int type, int reussi){
	super(a);
	this.setJoueurActeur(ja);
	this.setJoueurCible(jc);
	this.type     = type;
	this.reussi   = reussi;
    }


    //les getters
    public int getId() {
	return id;
    }

    public int getActionId(){
	return super.getId();
    }
    
    public int getType() {
    	return this.type;
    }
    
    public int  getReussi() {
    	return this.reussi;
    }
    
    //les setters
    public void setActionId(int i){
	super.setId(i);
    }

    public void setType(int type) {
    	this.type = type;
    }
    
    public void setReussi(int reussi) {
    	this.reussi = reussi;
    }

    
    
}

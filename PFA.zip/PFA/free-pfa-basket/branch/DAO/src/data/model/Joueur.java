package data.model;

import java.util.Date;

public class Joueur {

    public static int NO_ID = -1;
    
    public  int     id;
    private String  nom;
    private String  prenom;
    private String  pseudo;
    private Date    naissance;
    private boolean sexe;
    private String  photo;
    private String  nomUtilisateur;
    private String  mdp;
    private int     droits;
   
    
    public Joueur() {
    }
    
    public Joueur(String pseudo, int numero) {
	this.nom       = nom;
	this.prenom    = prenom;
	this.naissance = naissance;
	this.sexe      = sexe;
    }
    
    //constructor complet
    public Joueur(String nom, String prenom, String pseudo, Date naissance, boolean sexe, String photo, String nomUtilisateur, String mdp, int droits) {
	this.nom            = nom;
	this.prenom         = prenom;
	this.naissance      = naissance;
	this.sexe           = sexe;
	this.photo          = photo;
	this.nomUtilisateur = nomUtilisateur;
	this.mdp            = mdp;
	this.droits         = droits;
    }
    
     
    //getter
    public int getId(){
	return id;
    }
    
    public String getNom(){
	return nom;
    }

    public String getPrenom(){
	return prenom;
    }

    public String getPseudo(){
	return pseudo;
    }

    public Date getNaissance(){
	return naissance;
    }

    public boolean getSexe(){
	return sexe;
    }

    public String getPhoto(){
	return photo;
    }

    public String getNomUtilisateur(){
	return nomUtilisateur;
    }


    public String getMdp(){
	return mdp;
    }

    public int getDroits(){
	return droits;
    }



    //setter

    public void setId(int i){
	this.id = i;
    }

    public void setNom(String n){
	this.nom = n;
    }

    public void setPseudo(String p){
	this.pseudo = p;
    }

    public void setPrenom(String p){
	this.prenom = p;
    }

    public void  setNaissance(Date d){
	this.naissance = d;
    }

    public void setSexe(boolean b){
	this.sexe = b;
    }

    public void setPhoto(String p){
	this.photo = p;
    }

    public void setNomUtilisateur(String n){
	this.nomUtilisateur = n;
    }


    public void setMdp(String m){
	this.mdp = m;
    }

    public void setDroits(int d){
	this.droits = d;
    }

   @Override
   public String toString(){
       return "Nom: "+nom+"\nPrenom: "+prenom+"\n";


   }
    
}

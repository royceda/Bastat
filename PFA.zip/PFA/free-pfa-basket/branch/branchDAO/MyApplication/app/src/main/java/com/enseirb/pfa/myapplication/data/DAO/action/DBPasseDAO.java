package com.enseirb.pfa.myapplication.data.DAO.action;
 
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.enseirb.pfa.myapplication.data.DAO.BaseDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBJoueurDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBTempsDeJeuDAO;
import com.enseirb.pfa.myapplication.data.model.action.Passe;

import java.util.ArrayList;
import java.util.List;

public class DBPasseDAO extends BaseDAO {

    public static final String TABLE_NAME = "PASSE_DECISIVE";

    private static final String ID_FIELD_NAME               = "ID";
    private static final String TEMPS_DE_JEU_ID_FIELD_NAME  = "TEMPS_DE_JEU_ID";
    private static final String JOUEUR_ACTEUR_ID_FIELD_NAME = "JOUEUR_ACTEUR_ID";
    private static final String COMMENTAIRE_FIELD_NAME      = "COMMENTAIRE";
    private static final String JOUEUR_CIBLE_ID_FIELD_NAME  = "JOUEUR_CIBLE_ID";

    private static final String ID_FIELD_TYPE               = "INTEGER PRIMARY KEY AUTOINCREMENT";
    private static final String TEMPS_DE_JEU_ID_FIELD_TYPE  = "INTEGER";
    private static final String JOUEUR_ACTEUR_ID_FIELD_TYPE = "INTEGER";
    private static final String COMMENTAIRE_FIELD_TYPE      = "TEXT";
    private static final String JOUEUR_CIBLE_ID_FIELD_TYPE  = "INTEGER";

    private static final int NUM_COL_ID                     = 0;
    private static final int NUM_COL_TEMPS_DE_JEU_ID        = 1;
    private static final int NUM_COL_JOUEUR_ACTEUR_ID       = 2;
    private static final int NUM_COL_COMMENTAIRE            = 3;
    private static final int NUM_COL_JOUEUR_CIBLE_ID        = 4;


    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE
            + ", " + TEMPS_DE_JEU_ID_FIELD_NAME     + " " + TEMPS_DE_JEU_ID_FIELD_TYPE
            + ", " + JOUEUR_ACTEUR_ID_FIELD_NAME    + " " + JOUEUR_ACTEUR_ID_FIELD_TYPE
            + ", " + COMMENTAIRE_FIELD_NAME + " " + COMMENTAIRE_FIELD_TYPE
            + ", " + JOUEUR_CIBLE_ID_FIELD_NAME + " " + JOUEUR_CIBLE_ID_FIELD_TYPE
            + ", " + "FOREIGN KEY (" + TEMPS_DE_JEU_ID_FIELD_NAME +") "
                   + "REFERENCES "+ DBTempsDeJeuDAO.TABLE_NAME+"(ID) "
            + ", " + "FOREIGN KEY (" + JOUEUR_ACTEUR_ID_FIELD_NAME+") "
                   + "REFERENCES "+ DBJoueurDAO.TABLE_NAME+"(ID)"
            + ", " + "FOREIGN KEY (" + JOUEUR_CIBLE_ID_FIELD_NAME+") "
                   + "REFERENCES "+ DBJoueurDAO.TABLE_NAME+"(ID)";

    public DBPasseDAO(Context context) {
        super(context);
        this.mDb = this.open();
    }

    public long insert(Passe passe){
        ContentValues values = new ContentValues();
        values.put(TEMPS_DE_JEU_ID_FIELD_NAME, passe.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, passe.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, passe.getCommentaire());

        values.put(JOUEUR_CIBLE_ID_FIELD_NAME,passe.getJoueurCible());
        return  mDb.insert(TABLE_NAME, null, values);
    }

    public long update(int id, Passe passe){
        ContentValues values = new ContentValues();
        values.put(TEMPS_DE_JEU_ID_FIELD_NAME, passe.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, passe.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, passe.getCommentaire());

        values.put(JOUEUR_CIBLE_ID_FIELD_NAME,passe.getJoueurCible());
        return mDb.update(TABLE_NAME, values, ID_FIELD_NAME + " = " + id, null);
    }


    public int removeWithId(int id){
        return mDb.delete(TABLE_NAME, ID_FIELD_NAME + " = " +id, null);
    }


    public Passe getWithId(int id){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, TEMPS_DE_JEU_ID_FIELD_NAME,
                        JOUEUR_ACTEUR_ID_FIELD_NAME, COMMENTAIRE_FIELD_NAME, JOUEUR_CIBLE_ID_FIELD_NAME},
                ID_FIELD_NAME +"=" + id, null, null, null, null);
        return cursorToPasse(c);
    }


    public List<Passe> getAll(){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, TEMPS_DE_JEU_ID_FIELD_NAME,
                        JOUEUR_ACTEUR_ID_FIELD_NAME, COMMENTAIRE_FIELD_NAME, JOUEUR_CIBLE_ID_FIELD_NAME},
                null, null, null, null, null);
        return cursorToListPasse(c);
    }


    private List<Passe> cursorToListPasse(Cursor c){
        if (c.getCount() == 0)
            return null;

        List<Passe> liste = new ArrayList<Passe>();
        liste.clear();

        if (c.moveToFirst()) {
            do {
                Passe passe = new Passe();
                passe.setId(c.getInt(NUM_COL_ID));
                passe.setTempsDeJeu(c.getInt(NUM_COL_TEMPS_DE_JEU_ID));
                passe.setJoueurActeur(c.getInt(NUM_COL_JOUEUR_ACTEUR_ID));
                passe.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
                passe.setJoueurCible(c.getInt(NUM_COL_JOUEUR_CIBLE_ID));
                liste.add(passe);
            } while (c.moveToNext());
        }
        c.close();
        return liste;
    }


    private Passe cursorToPasse(Cursor c){
        if (c.getCount() == 0)
            return null;

        c.moveToFirst();
        Passe passe = new Passe();

        passe.setId(c.getInt(NUM_COL_ID));
        passe.setTempsDeJeu(c.getInt(NUM_COL_TEMPS_DE_JEU_ID));
        passe.setJoueurActeur(c.getInt(NUM_COL_JOUEUR_ACTEUR_ID));
        passe.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
        passe.setJoueurCible(c.getInt(NUM_COL_JOUEUR_CIBLE_ID));

        c.close();

        return passe;
    }


}

package com.enseirb.pfa.myapplication.data.model;

public class Equipe {
    private static int NO_ID = -1;

    private int id;
    String nom;
    String couleur;
    String photo;
    private String acronyme;

    //constructor
    public Equipe() {
        setId(NO_ID);
        setCouleur("");
        setPhoto("");
        setCouleur("");
        setAcronyme("");
    }

    public Equipe(String nom, String acronyme) {
        setId(NO_ID);
        setNom(nom);
        setAcronyme(acronyme);
        setCouleur("");
        setPhoto("");
    }

    public Equipe(String nom, String couleur, String photo) {
	    this.nom = nom;
	    this.couleur = couleur;
	    this.photo = photo;
    }

    //getter
    public String getNom() {
	return this.nom;
    }

    public    String getCouleur() {
	return this.couleur;
    }

    public String getPhoto() {
	return this.photo;
    }

    //setter
    public void setNom(String nom) {
	this.nom = nom;
    }

    public void setCouleur(String couleur) {
	this.couleur = couleur;
    }

    public void setPhoto(String photo) {
	this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public void setId(int i){
	this.id = i;
    }

    public String getAcronyme() {
        return acronyme;
    }

    public void setAcronyme(String acronyme) {
        this.acronyme = acronyme;
    }

    @Override
    public String toString(){
        return "Equipe: "+getNom()+" ("+getAcronyme()+")"+"\tId: "+getId();
    }


}

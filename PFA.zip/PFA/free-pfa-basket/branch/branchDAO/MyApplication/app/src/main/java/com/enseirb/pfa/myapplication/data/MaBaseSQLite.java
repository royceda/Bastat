package com.enseirb.pfa.myapplication.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.enseirb.pfa.myapplication.data.DAO.action.DBContreDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBEquipeDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBFauteDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBInterceptionDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBJoueurDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBPasseDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBPerteBalleDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBRebondDAO;
import com.enseirb.pfa.myapplication.data.DAO.action.DBShootDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBTempsDeJeuDAO;

public class MaBaseSQLite extends SQLiteOpenHelper {

    public MaBaseSQLite(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Model
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBJoueurDAO.TABLE_NAME + " ("
                + DBJoueurDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBTempsDeJeuDAO.TABLE_NAME + " ("
                + DBTempsDeJeuDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBEquipeDAO.TABLE_NAME + " ("
                + DBEquipeDAO.CREATE_TABLE_STATEMENT + ")");
        // Actions
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBShootDAO.TABLE_NAME + " ("
                + DBShootDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBRebondDAO.TABLE_NAME + " ("
                + DBRebondDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBPasseDAO.TABLE_NAME + " ("
                + DBPasseDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBContreDAO.TABLE_NAME + " ("
                + DBContreDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBInterceptionDAO.TABLE_NAME + " ("
                + DBInterceptionDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBFauteDAO.TABLE_NAME + " ("
                + DBFauteDAO.CREATE_TABLE_STATEMENT + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + DBPerteBalleDAO.TABLE_NAME + " ("
                + DBPerteBalleDAO.CREATE_TABLE_STATEMENT + ")");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Model
        db.execSQL("DROP TABLE " + DBJoueurDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBTempsDeJeuDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBEquipeDAO.TABLE_NAME + ";");
        // Actions
        db.execSQL("DROP TABLE " + DBShootDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBRebondDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBPasseDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBContreDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBInterceptionDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBFauteDAO.TABLE_NAME + ";");
        db.execSQL("DROP TABLE " + DBPerteBalleDAO.TABLE_NAME + ";");
        onCreate(db);


        //PS: il faudra adapter pour les autres table
    }

}


package com.enseirb.pfa.myapplication.data.DAO.action;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.enseirb.pfa.myapplication.data.DAO.BaseDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBJoueurDAO;
import com.enseirb.pfa.myapplication.data.DAO.DBTempsDeJeuDAO;
import com.enseirb.pfa.myapplication.data.model.action.Faute;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rchabot on 25/01/15.
 */
public class DBFauteDAO extends BaseDAO {
    public static final String TABLE_NAME = "FAUTE";

    private static final String ID_FIELD_NAME               = "ID";
    private static final String TEMPS_DE_JEU_ID_FIELD_NAME  = "TEMPS_DE_JEU_ID";
    private static final String JOUEUR_ACTEUR_ID_FIELD_NAME = "JOUEUR_ACTEUR_ID";
    private static final String COMMENTAIRE_FIELD_NAME      = "COMMENTAIRE";
    private static final String JOUEUR_CIBLE_ID_FIELD_NAME  = "JOUEUR_CIBLE_ID";

    private static final String ID_FIELD_TYPE               = "INTEGER PRIMARY KEY AUTOINCREMENT";
    private static final String TEMPS_DE_JEU_ID_FIELD_TYPE  = "INTEGER";
    private static final String JOUEUR_ACTEUR_ID_FIELD_TYPE = "INTEGER";
    private static final String COMMENTAIRE_FIELD_TYPE      = "TEXT";
    private static final String JOUEUR_CIBLE_ID_FIELD_TYPE  = "INTEGER";

    private static final int NUM_COL_ID                     = 0;
    private static final int NUM_COL_TEMPS_DE_JEU_ID        = 1;
    private static final int NUM_COL_JOUEUR_ACTEUR_ID       = 2;
    private static final int NUM_COL_COMMENTAIRE            = 3;
    private static final int NUM_COL_JOUEUR_CIBLE_ID        = 4;


    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE
            + ", " + TEMPS_DE_JEU_ID_FIELD_NAME     + " " + TEMPS_DE_JEU_ID_FIELD_TYPE
            + ", " + JOUEUR_ACTEUR_ID_FIELD_NAME    + " " + JOUEUR_ACTEUR_ID_FIELD_TYPE
            + ", " + COMMENTAIRE_FIELD_NAME + " " + COMMENTAIRE_FIELD_TYPE
            + ", " + JOUEUR_CIBLE_ID_FIELD_NAME + " " + JOUEUR_CIBLE_ID_FIELD_TYPE
            + ", " + "FOREIGN KEY (" + TEMPS_DE_JEU_ID_FIELD_NAME +") "
            + "REFERENCES "+ DBTempsDeJeuDAO.TABLE_NAME+"(ID) "
            + ", " + "FOREIGN KEY (" + JOUEUR_ACTEUR_ID_FIELD_NAME+") "
            + "REFERENCES "+ DBJoueurDAO.TABLE_NAME+"(ID)"
            + ", " + "FOREIGN KEY (" + JOUEUR_CIBLE_ID_FIELD_NAME+") "
            + "REFERENCES "+ DBJoueurDAO.TABLE_NAME+"(ID)";

    public DBFauteDAO(Context context) {
        super(context);
        this.mDb = this.open();
    }

    public long insert(Faute faute){
        ContentValues values = new ContentValues();
        values.put(TEMPS_DE_JEU_ID_FIELD_NAME, faute.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, faute.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, faute.getCommentaire());

        values.put(JOUEUR_CIBLE_ID_FIELD_NAME,faute.getJoueurCible());
        return  mDb.insert(TABLE_NAME, null, values);
    }

    public long update(int id, Faute faute){
        ContentValues values = new ContentValues();
        values.put(TEMPS_DE_JEU_ID_FIELD_NAME, faute.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, faute.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, faute.getCommentaire());

        values.put(JOUEUR_CIBLE_ID_FIELD_NAME,faute.getJoueurCible());
        return mDb.update(TABLE_NAME, values, ID_FIELD_NAME + " = " + id, null);
    }


    public int removeWithId(int id){
        return mDb.delete(TABLE_NAME, ID_FIELD_NAME + " = " +id, null);
    }


    public Faute getWithId(int id){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, TEMPS_DE_JEU_ID_FIELD_NAME,
                        JOUEUR_ACTEUR_ID_FIELD_NAME, COMMENTAIRE_FIELD_NAME, JOUEUR_CIBLE_ID_FIELD_NAME},
                ID_FIELD_NAME +"=" + id, null, null, null, null);
        return cursorToFaute(c);
    }


    public List<Faute> getAll(){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, TEMPS_DE_JEU_ID_FIELD_NAME,
                        JOUEUR_ACTEUR_ID_FIELD_NAME, COMMENTAIRE_FIELD_NAME, JOUEUR_CIBLE_ID_FIELD_NAME},
                null, null, null, null, null);
        return cursorToListFaute(c);
    }


    private List<Faute> cursorToListFaute(Cursor c){
        if (c.getCount() == 0)
            return null;

        List<Faute> liste = new ArrayList<Faute>();
        liste.clear();

        if (c.moveToFirst()) {
            do {
                Faute faute = new Faute();
                faute.setId(c.getInt(NUM_COL_ID));
                faute.setTempsDeJeu(c.getInt(NUM_COL_TEMPS_DE_JEU_ID));
                faute.setJoueurActeur(c.getInt(NUM_COL_JOUEUR_ACTEUR_ID));
                faute.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
                faute.setJoueurCible(c.getInt(NUM_COL_JOUEUR_CIBLE_ID));
                liste.add(faute);
            } while (c.moveToNext());
        }
        c.close();
        return liste;
    }


    private Faute cursorToFaute(Cursor c){
        if (c.getCount() == 0)
            return null;

        c.moveToFirst();
        Faute faute = new Faute();

        faute.setId(c.getInt(NUM_COL_ID));
        faute.setTempsDeJeu(c.getInt(NUM_COL_TEMPS_DE_JEU_ID));
        faute.setJoueurActeur(c.getInt(NUM_COL_JOUEUR_ACTEUR_ID));
        faute.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
        faute.setJoueurCible(c.getInt(NUM_COL_JOUEUR_CIBLE_ID));

        c.close();

        return faute;
    }


}

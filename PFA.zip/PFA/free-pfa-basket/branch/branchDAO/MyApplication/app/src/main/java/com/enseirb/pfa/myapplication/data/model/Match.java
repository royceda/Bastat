package com.enseirb.pfa.myapplication.data.model;

import java.sql.Date;

/**
 * Created by rchabot on 25/01/15.
 */
public class Match {
    private static int NO_ID = -1;

    private int id;
    private int tempsDeJeu;
    private int formationEquipeA;
    private int formationEquipeB;
    private String libelle;
    private int scoreEquipeA;
    private int scoreEquipeB;
    //private int arbitreChamp;
    //private int arbitreAssistant;
    //private Date date;


}

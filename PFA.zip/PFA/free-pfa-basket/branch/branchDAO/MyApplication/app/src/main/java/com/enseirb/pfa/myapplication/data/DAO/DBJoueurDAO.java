package com.enseirb.pfa.myapplication.data.DAO;
 
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.enseirb.pfa.myapplication.data.model.action.Joueur;

import java.util.ArrayList;
import java.util.List;

public class DBJoueurDAO extends BaseDAO {

    public  static final String TABLE_NAME             = "JOUEUR";

    private static final String ID_FIELD_NAME          = "ID";
    private static final String NOM_FIELD_NAME         = "NOM";
    private static final String PRENOM_FIELD_NAME      = "PRENOM";
    private static final String PSEUDO_FIELD_NAME      = "PSEUDO";
    private static final String NUMERO_FIELD_NAME      = "NUMERO";
    private static final String EQUIPE_ID_FIELD_NAME   = "EQUIPE";

    private static final String ID_FIELD_TYPE          = "INTEGER PRIMARY KEY AUTOINCREMENT";
    private static final String NOM_FIELD_TYPE         = "TEXT";
    private static final String PRENOM_FIELD_TYPE      = "TEXT";
    private static final String PSEUDO_FIELD_TYPE      = "TEXT";
    private static final String NUMERO_FIELD_TYPE      = "INTEGER";
    private static final String EQUIPE_ID_FIELD_TYPE   = "INTEGER";

    private static final int NUM_COL_ID          = 0;
    private static final int NUM_COL_NOM         = 1;
    private static final int NUM_COL_PRENOM      = 2;
    private static final int NUM_COL_PSEUDO      = 3;
    private static final int NUM_COL_NUMERO      = 4;
    private static final int NUM_COL_EQUIPE_ID   = 5;


    public static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE
	+ ", " + NOM_FIELD_NAME         + " " + NOM_FIELD_TYPE 
	+ ", " + PRENOM_FIELD_NAME      + " " + PRENOM_FIELD_TYPE
    + ", " + PSEUDO_FIELD_NAME      + " " + PSEUDO_FIELD_TYPE
    + ", " + NUMERO_FIELD_NAME      + " " + NUMERO_FIELD_TYPE
    + ", " + EQUIPE_ID_FIELD_NAME   + " " + EQUIPE_ID_FIELD_TYPE;
 
    public DBJoueurDAO(Context context){
        super(context);
        this.mDb = this.open();
    }

    public long insert(Joueur joueur){
	    ContentValues values = new ContentValues();

	    values.put(NOM_FIELD_NAME,             joueur.getNom());
	    values.put(PRENOM_FIELD_NAME,          joueur.getPrenom());
        values.put(PSEUDO_FIELD_NAME,          joueur.getPseudo());
        values.put(NUMERO_FIELD_NAME,          joueur.getNumero());
        values.put(EQUIPE_ID_FIELD_NAME,       joueur.getEquipeId());

	    return super.mDb.insert(TABLE_NAME, null, values);
    }

    public int update(int id, Joueur joueur){
	    ContentValues values = new ContentValues();
	    values.put(NOM_FIELD_NAME,             joueur.getNom());
	    values.put(PRENOM_FIELD_NAME,          joueur.getPrenom());
        values.put(PSEUDO_FIELD_NAME,          joueur.getPseudo());
        values.put(NUMERO_FIELD_NAME,          joueur.getNumero());
        values.put(EQUIPE_ID_FIELD_NAME,       joueur.getEquipeId());


        return super.mDb.update(TABLE_NAME, values, ID_FIELD_NAME + " = " + id, null);
    }
 
    public int removeWithId(int id){
	    return super.mDb.delete(TABLE_NAME, ID_FIELD_NAME + " = " +id, null);
    }

    public Joueur getWithId(int id){
	    Cursor c = super.mDb.query(TABLE_NAME, null,ID_FIELD_NAME +"=" + id, null, null, null, null);
	    return cursorToJoueur(c);
    }

    public List<Joueur> getAll(){
        Cursor c = super.mDb.query(TABLE_NAME, null, null, null, null, null, null);
        return cursorToListJoueur(c);
    }

    public List<Joueur> getJoueursEquipe(int equipeId){
        Cursor c = super.mDb.query(TABLE_NAME, null, EQUIPE_ID_FIELD_NAME + "= " + equipeId, null,
                null, null, null);
        return cursorToListJoueur(c);
    }


    private List<Joueur> cursorToListJoueur(Cursor c){
        if (c.getCount() == 0)
            return null;

        List<Joueur> listeJoueurs = new ArrayList<Joueur>();
        listeJoueurs.clear();

        if (c.moveToFirst()) {
            do {
                Joueur joueur = new Joueur();
                joueur.setId(c.getInt(NUM_COL_ID));
                joueur.setNom(c.getString(NUM_COL_NOM));
                joueur.setPrenom(c.getString(NUM_COL_PRENOM));
                joueur.setPseudo(c.getString(NUM_COL_PSEUDO));
                joueur.setEquipeId(c.getInt(NUM_COL_EQUIPE_ID));
                joueur.setNumero(c.getInt(NUM_COL_NUMERO));
                listeJoueurs.add(joueur);
            } while (c.moveToNext());
        }
        c.close();
        return listeJoueurs;
    }

    private Joueur cursorToJoueur(Cursor c){
        if (c.getCount() == 0)
            return null;

        c.moveToFirst();
        Joueur joueur = new Joueur();

        joueur.setId(c.getInt(NUM_COL_ID));
        joueur.setNom(c.getString(NUM_COL_NOM));
        joueur.setPrenom(c.getString(NUM_COL_PRENOM));
        joueur.setPseudo(c.getString(NUM_COL_PSEUDO));
        joueur.setEquipeId(c.getInt(NUM_COL_EQUIPE_ID));
        joueur.setNumero(c.getInt(NUM_COL_NUMERO));

        c.close();

        return joueur;
    }

}

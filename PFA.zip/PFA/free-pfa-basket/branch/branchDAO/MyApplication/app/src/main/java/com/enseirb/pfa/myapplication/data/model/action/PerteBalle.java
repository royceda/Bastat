package com.enseirb.pfa.myapplication.data.model.action;

import com.enseirb.pfa.myapplication.data.model.TempsDeJeu;
import com.enseirb.pfa.myapplication.data.model.action.Joueur;

/**
 * Created by rchabot on 25/01/15.
 */
public class PerteBalle {
    private static int NO_ID = -1;

    private int id;
    private int tempsDeJeu;
    private int joueurActeur;
    private String  commentaire;

    private int joueurCible;

    public PerteBalle() {
        setTempsDeJeu(NO_ID);
        setJoueurActeur(NO_ID);
        setCommentaire("");
        setJoueurCible(NO_ID);
    }

    public PerteBalle(TempsDeJeu temps, Joueur joueurActeur, Joueur joueurCible) {
        setTempsDeJeu(temps.getId());
        setJoueurActeur(joueurActeur.getId());
        setCommentaire("");
        setJoueurCible(joueurCible.getId());
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTempsDeJeu() {
        return tempsDeJeu;
    }

    public void setTempsDeJeu(int tempsDeJeu) {
        this.tempsDeJeu = tempsDeJeu;
    }

    public int getJoueurActeur() {
        return joueurActeur;
    }

    public void setJoueurActeur(int joueurActeur) {
        this.joueurActeur = joueurActeur;
    }

    public int getJoueurCible() {
        return joueurCible;
    }

    public void setJoueurCible(int joueurCible) {
        this.joueurCible = joueurCible;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire){
        this.commentaire = commentaire;
    }

    @Override
    public String toString(){
        return "Tps:"+getTempsDeJeu()+"\tA perdu: "+getJoueurActeur()+"\tA provoqué: "+getJoueurCible()+
                "\tId: "+getId();
    }
}


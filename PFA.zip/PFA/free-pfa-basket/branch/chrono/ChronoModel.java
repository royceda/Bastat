package fr.tests.stats.chrono;

import android.widget.Chronometer;

/**
 * Created by lionel on 26/01/15.
 */
public class ChronoModel {
    private long quarter;
    private long quarterLength;

    public ChronoModel(long quarter, long quarterLength) {
        this.quarter = quarter;
        this.quarterLength = quarterLength;
    }

    public long getQuarter() {return this.quarter;}

    public long getQuarterLength() {return this.quarterLength;}

}

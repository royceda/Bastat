package fr.basket.stat;

class Shoot extends Action{

	private int     id;
	private int     type;
	private boolean reussi;

    Shoot(int id, int actionId, int type, int reussi){
		this.id       = id;
		this.actionId = actionId;
		this.type     = type;
		this.reussi   = reussi;
    }


//les getters
    int getId() {}

    int getType() {
    	return this.type;
    }

    boolean getReussi() {
    	return this.reussi;
    }

//les setters
    void setType(int type) {
    	this.type = type;
    }

    void setReussi(int reussi) {
    	this.reussi = reussi;
    }

}

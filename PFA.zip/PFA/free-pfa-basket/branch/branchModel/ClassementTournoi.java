package fr.basket.stat;

public class ClassementTournoi {
	private int id;
	private int place;
	private Equipe equipe;
	private Tournoi tournoi;

//constructor
	ClassementTournoi() {
		this.place = 0;
	}

//getter
	int getPlace() {
		return this.place;
	}

	Equipe getEquipe() {
		return this.equipe;
	}

	Tournoi getTournoi() {
		return this.tournoi;
	}

//setter
	void setPlace(int place) {
		this.place = place;
	}

	void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

	void setTournoit(Tournoi tournoi) {
		this.tournoi = tournoi;
	}
}
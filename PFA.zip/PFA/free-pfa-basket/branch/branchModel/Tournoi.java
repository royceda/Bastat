package fr.basket.stat;

public class Tournoi {

	private int id;
	private String libelle;
	private String lieu;
	private int nbEquipeMax;

//constructor
	Tournoi() {
	}

//getter
	String getLibelle() {
		return this.libelle;
	}

	String getLieu() {
		return this.lieu;
	}

	int getNbEquipeMax() {
		return this.nbEquipeMax;
	}

//setter
	void setLibelle(String label) {
		this.libelle = label;
	}

	void setLieu(String lieu) {
		this.lieu = lieu;
	}

	void setNbEquipeMax(int nbEquipe) {
		this.nbEquipeMax = nbEquipe;
	}

}
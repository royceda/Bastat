package fr.basket.stat;

import java.util.Date;

class Phase extends PhasePoule, PhaseTableau{

	private int id;
	private Tournoi tournoiPhase;
	private String libelle;
	private Date date;
	private int ordreTemporel;
	private int type;
	private int specifiqueId;

//constructor
	Phase() {
		super();
	}

//getter
	String getLibelle() {
		return this.libelle;
	}

	Date getDate() {
		return this.date;
	}

	int getOrdreTemporel() {
		return this.ordreTemporel;
	}

	int getType() {
		return this.type;
	}

	int getSpecifiqueId() {
		return this.specifiqueId;
	}

//setter
	void setLibelle(String label) {
		this.libelle = label;
	}

	void setDate(Date date) {
		this.date = date;
	}

	void setOrdreTemporel(int ordreTemporel) {
		this.ordreTemporel = ordreTemporel;
	}

	void setType(int type) {
		this.type = type;
	}

	void setSpecifiqueId(int specifiqueId) {
		this.specifiqueId = specifiqueId;
	}

}
package fr.basket.stat;

public class TournoiEquipe {

	private int id;
	private Equipe equipeId;
	Map<Integer, Tournoi> tournoi;

//constructor
	TournoiEquipe() {

	}

}
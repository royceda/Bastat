package fr.basket.stat;

public class PouleEquipe {

	private int id;
	private Poule poule;
	private String regle;

//constructor
	PouleEquipe() {
	}

//getter
	Poule getPoule() {
		return this.poule;
	}

	String getRegle() {
		return this.regle;
	}

//setter
	void setPoule(Poule poule) {
		this.poule = poule;
	}

	void setRegle(int regle) {
		this.regle = regle;
	}

}
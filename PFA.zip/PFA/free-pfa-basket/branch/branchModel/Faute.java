package fr.basket.stat;

public class Faute extends Action {
	int id;
	int type;

	//constructor
	Faute() {
		super();
	}

	//getter
	int getType() {
		return this.type;
	}

	//setter
	void setType(int type) {
		this.type = type;
	}
}

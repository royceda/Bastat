package fr.basket.stat;

class PasseDecisive extends Action{

	private int id;

	PasseDecisive() {
		super();
	}

	PasseDecisive(TempsDeJeu temps, Joueur joueurActeur, Joueur joueurCible) {
		super(temps, joueurActeur, joueurCible);
	}

}


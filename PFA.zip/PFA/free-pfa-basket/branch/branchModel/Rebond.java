package fr.basket.stat;

class Rebond extends Action{

	private int id;

//constructor
	Rebond() {
		super();
	}
	
}
package fr.basket.stat;

public class PouleMatch {

	private int id;
	private Poule poule;

//constructor
	PouleMatch() {
	}

//getter
	Poule getPoule() {
		return this.poule;
	}

//setter
	void setPoule(Poule poule) {
		this.poule = poule;
	}
}
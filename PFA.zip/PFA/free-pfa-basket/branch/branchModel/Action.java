package fr.basket.stat;



public abstract class Action {
	protected int id;
	protected TempsDeJeu temps;
	protected Joueur joueurActeur;
	protected Joueur joueurCible;
	protected String commentaire;

	//constructor

	public Action() {

	}

	public Action(TempsDeJeu temps, Joueur acteur, Joueur cible) {
		this.temps = temps;
		this.joueurActeur = acteur;
		this.joueurCible = cible;
	}

	//getter

	TempsDeJeu getTemps() {
		return this.temps;
	}

	Joueur getJoueurActeur() {
		return this.joueurActeur;
	}

	Joueur getJoueurCible() {
		return this.joueurCible;
	}

	String getCommentaire() {
		return this.commentaire;
	}

	//setters

	void setTempsDeJeu(TempsDeJeu temps) {
		this.temps = temps;
	}

	void setJoueurActeur(Joueur acteur) {
		this.joueurActeur = acteur;
	}

	void setJoueurCible(Joueur cible) {
		this.joueurCible = cible;
	}

	void setCommentaire(String comment) {
		this.commentaire = comment;
	}

}


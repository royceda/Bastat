package fr.basket.stat;

class Turnover extends Action{

	private int id;


//constructor
    Turnover() {}


}

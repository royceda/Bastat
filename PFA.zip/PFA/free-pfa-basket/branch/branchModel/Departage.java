package fr.basket.stat;

public class Departage {
	Poule poule;
	Equipe equipe;
	int points;

//constructor
	Departage() {
	}

//getter
	Poule getPoule() {
		return this.poule;
	}

	Equipe getEquipe() {
		return this.equipe;
	}

	int getPoints() {
		return this.points;
	}

//setter
	void setPoule(Poule poule) {
		this.poule = poule;
	}

	void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

	void setPoints(int points) {
		this.points = points;
	}
}
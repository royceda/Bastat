package fr.basket.stat;

import java.util.Map;
import java.util.Date;

public class Match {
	int id;
	String libelle;
	private	Formation equipes[] = new Formation[2];
	private Date date;
	Map<Integer, Action> historique;
	private int score[] = new int[2];
	private Date ordreTemporel;

//constructor
	public Match() {
		score = new int[]{0,0};
		historique.clear();
	}

	public Match(Formation formationEquipe1, Formation formationEquipe2) {
		score = new int[]{0,0};
		historique.clear();
		equipes = new Formation[]{formationEquipe1, formationEquipe2};
	}

//getter
	String getLibelle() {
		return this.libelle;
	}

	Formation getEquipes() {
		return this.equipes;
	}

	Date getDate() {
		return this.date;
	}

	Map<Integer, Action> getHistorique() {
		return this.historique;
	}

	int[] getScore() {
		return this.score;
	}

	Date getOrdreTemporel() {
		return this.ordreTemporel;
	}

//setter
	void setLibelle(String label) {
		this.libelle = label;
	}

	void setEquipes(Equipes equipes[]) {
		this.equipes = equipes;
	}

	void setDate(Date date) {
		this.date = date;
	}

	void setScore(int score[]) {
		this.score = score;
	}


	public void incrementeScore(Equipe equipe) {
		int indexEquipe = 2;

		for (int i=0 ; i<2 ; i++) {
			if (equipes[i].id == equipe.id)
				indexEquipe = i;
		}

		if (indexEquipe != 2)
			score[indexEquipe]++;
			
	}

	public void decrementeScore(Equipe equipe) {
		int indexEquipe = 2;

		for (int i=0 ; i<2 ; i++) {
			if (equipes[i].id == equipe.id)
				indexEquipe = i;
		}

		if (indexEquipe != 2)
			score[indexEquipe]--;
			
	}

	public void saisieAction(Action actionAjouter) {
		historique.put(actionAjouter.id, actionAjouter);
	}

	public void supprimerAction(Action actionSupprimer) {
		historique.remove(actionSupprimer.id);
	}

	public void modifierAction(Action actionAvant, Action actionApres) {
		this.supprimerAction(actionAvant);
		this.saisieAction(actionApres);
	}

}
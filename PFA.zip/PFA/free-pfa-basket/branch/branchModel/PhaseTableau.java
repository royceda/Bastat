package fr.basket.stat;

public class PhaseTableau {

	private int id;
	private Phase phaseId;
	private int stat;

	PhaseTableau() {
		this.stat = 0;
	}

	setStat(int stat) {
		this.stat = stat;
	}

}
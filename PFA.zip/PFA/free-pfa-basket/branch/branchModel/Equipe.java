package fr.basket.stat;

class Equipe {
	int id;
	String nom;
	String couleur;
	String photo;

//constructor
	Equipe() {

	}

	Equipe(String nom, String couleur, String photo) {
		this.nom = nom;
		this.couleur = couleur;
		this.photo = photo;
	}

//getter
	String getNom() {
		return this.nom;
	}

	String getCouleur() {
		return this.couleur;
	}

	String getPhoto() {
		return this.photo;
	}

//setter
	void setNom(String nom) {
		this.nom = nom;
	}

	void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	void setPhoto(String photo) {
		this.photo = photo;
	}
}
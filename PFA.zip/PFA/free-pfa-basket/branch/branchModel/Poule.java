package fr.basket.stat;

public class Poule {

	private int id;
	private String libelle;
	private PhasePoule phasePoule;
	private int etat;
	private int pointVictoire;
	private int pointDefaite;
	private int pointNul;
	private int goalAverageEcartMax;


//constructor
	Poule() {
		this.pointVictoire = 0;
		this.pointDefaite = 0;
		this.pointNul = 0;
		this.goalAverageEcartMax = 0;
	}

//getter
	String getLibelle() {
		return this.libelle;
	}

	PhasePoule getPhasePoule() {
		return this.phasePoule;
	}

	int getEtat() {
		return this.etat;
	}

	int getPointVictoire(int point) {
		return this.pointVictoire;
	}

	int getPointDefaite(int point) {
		return this.pointDefaite;
	}

	int getPointNul(int point) {
		return this.pointNul;
	}

//setter
	void setLibelle(String label) {
		this.libelle = label;
	}

	void setPhasePoule(Poule phasePoule) {
		this.phasePoule = phasePoule;
	}

	void setEtat(int etat) {
		this.etat = etat;
	}

	void setPointVictoire(int point) {
		this.pointVictoire = point;
	}

	void setPointDefaite(int point) {
		this.pointDefaite = point;
	}

	void setPointNul(int point) {
		this.pointNul = point;
	}

}
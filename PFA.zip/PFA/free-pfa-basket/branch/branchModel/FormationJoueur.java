package fr.basket.stat;

class FormationJoueur {

	Formation formation;
	Joueur joueur;
	String numero;

//constructor
	FormationJoueur() {
	}

//getter
	Formation getFormation() {
		return this.formation;
	}

	Joueur getJoueur() {
		return this.joueur;
	}

	String getNumero() {
		return this.numero;
	}

//setter
	void setFormation(Formation formation) {
		this.formation = formation;
	}

	void setJoueur(Joueur joueur) {
		this.joueur = joueur;
	}

	void setNumero(String numero) {
		this.numero = numero;
	}

}
package fr.basket.stat;

public class TempsDeJeu {

	private int id;
	private int matchId;
	private int ordreTemporel;
	private String libelle;
	private int duree;
	private int tempsRestant;
	private int nbFauteEquipe;

//constructor
	TempsDeJeu() {
		this.tempsRestant = this.duree;
		this.nbFauteEquipe = 0;
	}

//getter
	int getOrdreTemporel() {
		return this.ordreTemporel;
	}

	String getLibelle() {
		return this.libelle;
	}

	int getDuree() {
		return this.duree;
	}

	int getTempsRestant() {
		return this.tempsRestant;
	}

	int getNbFauteEquipe() {
		return this.nbFauteEquipe;
	}

//setter
	void setOrdreTemporel(int ordre) {
		this.ordreTemporel = ordre;
	}

	void setLibelle(String label) {
		this.libelle = label;
	}

	void setDuree(int duree) {
		this.duree = duree;
	}

	void setTempsRestant(int tempsRestant) {
		this.tempsRestant = tempsRestant;
	}

	void setNbFauteEquipe(int nbFaute) {
		this nbFauteEquipe = nbFaute;
	}

}
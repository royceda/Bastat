package fr.basket.stat;

public class PhasePoule {

	private int id;
	private Poule poule;
	private int nbPoule;
	private int nbPeriodeMatch;
	private int dureePeriodeMatch;

//constructor
	PhasePoule() {
		this.nbPoule = 0;
		this.nbPeriodeMatch = 0;
		this.dureePeriodeMatch = 0;
	}

//getter
	int getNbPoule() {
		return this.nbPoule;
	}

	int getNbPeriodeMatch() {
		return this.nbPeriodeMatch;
	}

	int getDureePeriodeMatch() {
		return this.dureePeriodeMatch;
	}

//setter
	void setNbPoule(int nbPoule) {
		this.nbPoule = nbPoule;
	}

	void setNbPoule(int nbPeriodeMatch) {
		this.nbPeriodeMatch = nbPeriodeMatch;
	}

	void setDureePeriodeMatch(int dureePeriodeMatch) {
		this.dureePeriodeMatch = dureePeriodeMatch;
	}


}
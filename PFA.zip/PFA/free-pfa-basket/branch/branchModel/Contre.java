package fr.basket.stat;

public class Contre extends Action {
	int id;

//constructor
	Contre() {
		super();
	}
}
package fr.basket.stat;

import java.util.Date;

class Joueur {

	public  int     id;
	private String  nom;
	private String  prenom;
	private String  pseudo;
	private Date    naissance;
	private boolean sexe;
	private String  photo;
	private String  nomUtilisateur;
	private String  mdp;
	private int     droits;

	private Action[] stat;

	Joueur() {
	}

	Joueur(String pseudo, int numero) {
		this.nom = nom;
		this.prenom = prenom;
		this.naissance = naissance;
		this.sexe = sexe;
	}

	//constructor complet
	Joueur(String nom, String prenom, String pseudo, Date naissance, boolean sexe, String photo,
			String nomUtilisateur, String mdp, int droits) {
		this.nom = nom;
		this.prenom = prenom;
		this.naissance = naissance;
		this.sexe = sexe;
		this.photo = photo;
		this.nomutilisateur = nomUtilisateur;
		this.mdp = mdp;
		this.droits = droits;
	}

	void addRebound(boolean type) {
		Rebound r = new Rebound(type);
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addFoul(boolean type) {
		Foul f = new Foul(type);
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addShoot(int type, booelan reussi) {
		Shoot s = new Shoot(type, reussi);
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addAssist() {
		Assist a = new Assist();
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addTurnover() {
		Turnover t = new Turnover();
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addSteal() {
		Steal s = new Steal();
		//ajout dans stat[] (list ou array ou etc..)
	}

	void addBlock() {
		Block b = new Block();
		//ajout dans stat[] (list ou array ou etc..)
	}

}

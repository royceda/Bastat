package fr.basket.stat;

class Formation {

	int id;
	Match match;
	Equipe equipe;

//constructor
	Formation() {
	}

//getter
	Match getMatch() {
		return this.match;
	}

	Equipe getEquipe() {
		return this.equipe;
	}

//setter
	void setMatch(Match match) {
		this.match = match;
	}

	void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

}
package fr.basket.stat;

public class Ligue {
	int id;
	String libelle;
	int type;
	int nbTournoiClass;

//constructor
	Ligue() {
	}

//getter
	String getLibelle() {
		return this.libelle;
	}

	int getType() {
		return this.type;
	}

	int getNbTournoiClass() {
		return nbTournoiClass;
	}


//setter
	void setLibelle(String label) {
		this.libelle = label;
	}

	void setType(int type) {
		this.type = type;
	}

	void setNbTournoiClass(int nbTournoiClass) {
		this.nbTournoiClass = nbTournoiClass;
	}


}
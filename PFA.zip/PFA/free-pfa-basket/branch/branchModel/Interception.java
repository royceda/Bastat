package fr.basket.stat;

public class Interception extends Action {
	int id;

	Interception() {
		super();
	}
}
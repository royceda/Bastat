Pour faire usage de la DAO dans l'interface:

Instancier tous les DBxxxDAO dont vous avez besoin de la façon suivante: 
	   BDxxxDAO tableXxx = new DBxxxDAO(this);

Pour chaque objet les constructeurs disponibles sont dans data/model/xxx.java. 

L'insertion des objets dans la base de données se fait en appellant la méthode insert sur l'objet tableXxx
Par exemple tableJoueur.insert(Joueur);

Les méthodes disponibles pour l'insertion et la récupération de données sont:
    - insert
    - update
    - removeWithId
    - getWithId
    - getAll
    - c'est tout, pour le moment...

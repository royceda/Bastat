package com.enseirb.pfa.bastats.data.model.action;


public class Joueur {

    public static final int NO_ID = -1;

    private int     id;
    private String  nom;
    private String  prenom;
    private String  pseudo;

    private int numero;
    private int equipeId;

    public Joueur(){
        this.id = NO_ID;
        this.nom = "";
        this.prenom = "";
        setEquipeId(NO_ID);
        setNumero(NO_ID);
    }

    public Joueur(String pseudo, int numero, int equipeId) {
        this.id = NO_ID;
        this.pseudo = pseudo;
        this.nom = "";
        this.prenom = "";
        setEquipeId(equipeId);
        setNumero(numero);
    }

    public Joueur(String nom, String prenom, int numero, int equipeId) {
        this.id = NO_ID;
        this.nom = nom;
        this.prenom = prenom;
        this.pseudo = "";
        setEquipeId(equipeId);
        setNumero(numero);
    }

    public Joueur(String nom, String prenom, int equipeId) {
        this.id = NO_ID;
        this.nom = nom;
        this.prenom = prenom;
        this.pseudo = "";
        setEquipeId(equipeId);
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    @Override
    public String toString(){
        return "Numéro: "+getNumero()+ "\tNom: "+nom+"\tPrenom: "+prenom+"\tPseudo :"+getPseudo()+"\tId: "+id
                + "\tEquipe: "+getEquipeId();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getEquipeId() {
        return equipeId;
    }

    public void setEquipeId(int equipeId) {
        this.equipeId = equipeId;
    }
}

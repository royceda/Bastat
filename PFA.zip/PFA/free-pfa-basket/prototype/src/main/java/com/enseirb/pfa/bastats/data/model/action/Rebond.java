package com.enseirb.pfa.bastats.data.model.action;

import com.enseirb.pfa.bastats.data.model.TempsDeJeu;
import com.enseirb.pfa.bastats.data.model.action.Joueur;

public class Rebond {
    public static int NO_ID = -1;
    // 4 champs action
    private int     id;
    private int     tempsDeJeu;
    private int     joueurActeur;
    private String  commentaire;

    private String caractere; // OFF ou DEF

    public Rebond(){
        setTempsDeJeu(NO_ID);
        setJoueurActeur(NO_ID);
        setCaractere("");
        setCommentaire("");
    }

    public Rebond(TempsDeJeu tdj, Joueur joueur, String caractere){
        setTempsDeJeu(tdj.getId());
        setJoueurActeur(joueur.getId());
        setCaractere(caractere);
        setCommentaire("");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTempsDeJeu() {
        return tempsDeJeu;
    }

    public void setTempsDeJeu(int tempsDeJeu) {
        this.tempsDeJeu = tempsDeJeu;
    }

    public int getJoueurActeur() {
        return joueurActeur;
    }

    public void setJoueurActeur(int joueurActeur) {
        this.joueurActeur = joueurActeur;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public String getCaractere() {
        return caractere;
    }

    public void setCaractere(String caractère) {
        this.caractere = caractère;
    }

    @Override
    public String toString(){
        return "Tps:"+getTempsDeJeu()+"\tJoueur: "+getJoueurActeur()+"\tGenre: "+getCaractere()+
                "\tId: "+getId();
    }
}

package com.enseirb.pfa.bastats.data.DAO.action;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.enseirb.pfa.bastats.data.DAO.BaseDAO;
import com.enseirb.pfa.bastats.data.model.action.Action;

import java.util.ArrayList;
import java.util.List;


public class DBActionDAO extends BaseDAO {

    public static final String TABLE_NAME                   = "ACTION";

    private static final String ID_FIELD_NAME               = "ID";
    private static final String TEMPS_DE_JEU_FIELD_NAME     = "TEMPS_DE_JEU";
    private static final String JOUEUR_ACTEUR_ID_FIELD_NAME = "JOUEUR_ACTEUR_ID";
    private static final String COMMENTAIRE_FIELD_NAME      = "COMMENTAIRE";
    private static final String TYPE_FIELD_NAME             = "TYPE";

    private static final String ID_FIELD_TYPE               = "INTEGER PRIMARY KEY AUTOINCREMENT";
    private static final String TEMPS_DE_JEU_FIELD_TYPE     = "INTEGER";
    private static final String JOUEUR_ACTEUR_ID_FIELD_TYPE = "INTEGER";
    private static final String COMMENTAIRE_FIELD_TYPE      = "TEXT";
    private static final String TYPE_FIELD_TYPE             = "INTEGER";

    private static final int NUM_COL_ID          = 0;
    private static final int NUM_COL_TDJ         = 1;
    private static final int NUM_COL_ACTEUR      = 2;
    private static final int NUM_COL_COMMENTAIRE = 3;
    private static final int NUM_COL_TYPE        = 4;

    private static final String CREATE_TABLE_STATEMENT = ID_FIELD_NAME + " " + ID_FIELD_TYPE
            + ", " + TEMPS_DE_JEU_FIELD_NAME     + " " + TEMPS_DE_JEU_FIELD_TYPE
            + ", " + JOUEUR_ACTEUR_ID_FIELD_NAME + " " + JOUEUR_ACTEUR_ID_FIELD_TYPE
            + ", " + COMMENTAIRE_FIELD_NAME      + " " + COMMENTAIRE_FIELD_TYPE
            + ", " + TYPE_FIELD_NAME             + " " + TYPE_FIELD_TYPE;


    public DBActionDAO (Context context){
        super(context);
        this.mDb = this.open();
    }

    public long insert(Action action){
        ContentValues values = new ContentValues();

        values.put(TEMPS_DE_JEU_FIELD_NAME, action.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, action.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, action.getCommentaire());
        values.put(TYPE_FIELD_NAME, action.getType());

        return super.mDb.insert(TABLE_NAME, null, values);
    }

    public int update(int id, Action action){
        ContentValues values = new ContentValues();

        values.put(TEMPS_DE_JEU_FIELD_NAME, action.getTempsDeJeu());
        values.put(JOUEUR_ACTEUR_ID_FIELD_NAME, action.getJoueurActeur());
        values.put(COMMENTAIRE_FIELD_NAME, action.getCommentaire());
        values.put(TYPE_FIELD_NAME, action.getType());

        return super.mDb.update(TABLE_NAME, values, ID_FIELD_NAME + " = " + id, null);
    }

    public int removeWithId(int id){
        return super.mDb.delete(TABLE_NAME, ID_FIELD_NAME + " = " +id, null);
    }

    public Action getWithId(int id){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, JOUEUR_ACTEUR_ID_FIELD_NAME,
                        COMMENTAIRE_FIELD_NAME, TYPE_FIELD_NAME},
                ID_FIELD_NAME +"=" + id, null, null, null, null);
        return cursorToAction(c);
    }

    public List<Action> getAll(){
        Cursor c = super.mDb.query(TABLE_NAME, new String[] {ID_FIELD_NAME, JOUEUR_ACTEUR_ID_FIELD_NAME,
                COMMENTAIRE_FIELD_NAME, TYPE_FIELD_NAME} , null, null, null, null, null);
        return cursorToListAction(c);
    }

    private List<Action> cursorToListAction(Cursor c){
        if (c.getCount() == 0)
            return null;

        List<Action> listeActions = new ArrayList<Action>();
        listeActions.clear();

        if (c.moveToFirst()) {
            do {
                Action action = new Action();
                action.setId(c.getInt(NUM_COL_ID));
                action.setJoueurActeur(c.getInt(NUM_COL_ACTEUR));
                action.setTempsDeJeu(c.getInt(NUM_COL_TDJ));
                action.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
                action.setType(c.getInt(NUM_COL_TYPE));
                listeActions.add(action);
            } while (c.moveToNext());
        }
        c.close();
        return listeActions;
    }

    private Action cursorToAction(Cursor c){
        if (c.getCount() == 0)
            return null;

        c.moveToFirst();
        Action action = new Action();
        action.setId(c.getInt(NUM_COL_ID));
        action.setJoueurActeur(c.getInt(NUM_COL_ACTEUR));
        action.setTempsDeJeu(c.getInt(NUM_COL_TDJ));
        action.setCommentaire(c.getString(NUM_COL_COMMENTAIRE));
        action.setType(c.getInt(NUM_COL_TYPE));
        c.close();

        return action;
    }
}

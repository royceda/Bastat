package com.enseirb.pfa.bastats;


        import android.app.Fragment;
        import android.os.Bundle;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.Chronometer;
        import android.os.SystemClock;

        import java.util.concurrent.TimeUnit;

/**
 * Created by lionel on 26/01/15.
 */
public class ChronoFragment extends Fragment {
    private Chronometer chrono;
    private static long time;
    private long timeWhenStopped = 0;
    private int currentQuarter = 1;
    boolean pauseState = true;
    private ChronoModel mModel = new ChronoModel(4, 10);

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chrono,
                container, false);
        chrono = (Chronometer) view.findViewById(R.id.chronometer);
        final Button start = (Button) view.findViewById(R.id.button);
        Button reset = (Button) view.findViewById(R.id.button2);

        chrono.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener(){
            @Override
            public void onChronometerTick(Chronometer cArg) {
                time = SystemClock.elapsedRealtime() - cArg.getBase();
            }
        });

        start.setText("START");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pauseState) {
                    chrono.setBase(SystemClock.elapsedRealtime() + timeWhenStopped);
                    chrono.start();
                    pauseState = false;
                    start.setText("STOP");
                } else {
                    timeWhenStopped = chrono.getBase() - SystemClock.elapsedRealtime();
                    chrono.stop();
                    System.out.println(TimeUnit.MILLISECONDS.toMinutes(timeWhenStopped) + ":" + TimeUnit.MILLISECONDS.toSeconds(timeWhenStopped));
                    System.out.println(getTime());
                    pauseState = true;
                    start.setText("START");
                }
            }
        });

        reset.setText("RESET");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                timeWhenStopped = 0;
                chrono.setBase(SystemClock.elapsedRealtime());
                chrono.stop();
            }
        });

        return view;
    }

    public static String getTime() {
        return (TimeUnit.MILLISECONDS.toMinutes(time)) + ":" + (TimeUnit.MILLISECONDS.toSeconds(time) % 60);
    }

}
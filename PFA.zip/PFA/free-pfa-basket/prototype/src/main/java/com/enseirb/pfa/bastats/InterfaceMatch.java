package com.enseirb.pfa.bastats;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.enseirb.pfa.bastats.data.DAO.DBEquipeDAO;
import com.enseirb.pfa.bastats.data.DAO.DBJoueurDAO;
import com.enseirb.pfa.bastats.data.DAO.DBTempsDeJeuDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBContreDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBFauteDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBInterceptionDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBPasseDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBPerteBalleDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBRebondDAO;
import com.enseirb.pfa.bastats.data.DAO.action.DBShootDAO;
import com.enseirb.pfa.bastats.data.model.TempsDeJeu;
import com.enseirb.pfa.bastats.data.model.action.Contre;
import com.enseirb.pfa.bastats.data.model.action.Faute;
import com.enseirb.pfa.bastats.data.model.action.Interception;
import com.enseirb.pfa.bastats.data.model.action.Joueur;
import com.enseirb.pfa.bastats.data.model.action.PerteBalle;
import com.enseirb.pfa.bastats.data.model.action.Rebond;
import com.enseirb.pfa.bastats.data.model.action.Shoot;

import java.util.ArrayList;
import java.util.List;

import static com.enseirb.pfa.bastats.ChronoFragment.*;


public class InterfaceMatch extends ActionBarActivity {
    private int i = 2;
    private static final int RED = 0;
    private static final int GREEN = 1;
    private static final int GRAY = 2;

    private Context mCtx;
    private String nomEquipeA;
    private String nomEquipeB;

    int equipeOff;

    private DBEquipeDAO tableEquipe;
    private DBJoueurDAO tableJoueur;
    private DBShootDAO tableShoot;
    private DBContreDAO tableContre;
    private DBFauteDAO tableFaute;
    private DBInterceptionDAO tableInterception;
    private DBTempsDeJeuDAO tableTempsDeJeu;
    private DBRebondDAO tableRebond;
    private DBPasseDAO tablePasse;
    private DBPerteBalleDAO tablePerteBalle;

    private List<Joueur> listeJoueursA = new ArrayList<Joueur>();
    private List<Joueur> listeJoueursB = new ArrayList<Joueur>();

    private int[] row_buttons_str_off = {
            R.string.tir_2pts,
            R.string.tir_2pts,
            R.string.rebond_off,
            R.string.faute_off,
            R.string.turnover
    };

    private int[] row_buttons_str_def = {
            R.string.block ,
            R.string.rebond_def,
            R.string.faute_def,
            R.string.steal
    };

    private int[] row_buttons_id_off = {
            R.id.tir_2,
            R.id.tir_2r,
            R.id.rebond_off,
            R.id.faute_off,
            R.id.turnover
    };

    private int[] row_buttons_id_def = {
            R.id.block,
            R.id.rebond_def,
            R.id.faute_def,
            R.id.steal
    };

    private int[] row_buttons_color_off = {
            GREEN,
            RED,
            GRAY,
            GRAY,
            GRAY
    };

    private int[] row_buttons_color_def = {
            GRAY,
            GRAY,
            GRAY,
            GRAY
    };

    private TableLayout tableLayoutLeft;
    private TableLayout tableLayoutRight;

    private int idA;
    private int idB;

    private ListView mHistoriqueListView;
    private ArrayAdapter<String> mHistoriqueListAdapter;
    private List<String> mHistorique;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interface_match);
        mCtx = this;
        // Creation du layout
        initDAO(mCtx);
        initHistorique();
        Intent intent = getIntent();
        initTeamLayouts(intent);

    }

    private void initTeamLayouts(Intent intent) {
        tableLayoutLeft = (TableLayout) findViewById(R.id.interface_match_left_table);
        tableLayoutRight = (TableLayout) findViewById(R.id.interface_match_right_table);

        nomEquipeA = intent.getStringExtra("equipeA");
        nomEquipeB = intent.getStringExtra("equipeB");
        TextView equipeAView = (TextView) findViewById(R.id.team_1);
        TextView equipeBView = (TextView) findViewById(R.id.team_2);
        equipeAView.setText(nomEquipeA);
        equipeBView.setText(nomEquipeB);

        idA = tableEquipe.getEquipeId(nomEquipeA);
        idB = tableEquipe.getEquipeId(nomEquipeB);

        equipeOff = idB;

        listeJoueursA.clear();
        listeJoueursB.clear();
        listeJoueursA.addAll(tableJoueur.getJoueursEquipe(idA));
        listeJoueursB.addAll(tableJoueur.getJoueursEquipe(idB));

        fillTeamLayouts();
    }

    public void createOffenseLayout(TableLayout tl, List<Joueur> listeJoueurs) {
        for (int j = 0; j < listeJoueurs.size(); j++) {
            Joueur tmp = listeJoueurs.get(j);
            createTableRow(tl, j, tmp.getNumero() + " " +tmp.getPseudo(),
                    row_buttons_id_off, row_buttons_str_off, row_buttons_color_off);
        }
    }

    public void createDefenseLayout(TableLayout tl, List<Joueur> listeJoueurs) {
        for (int j = 0; j < listeJoueurs.size(); j++) {
            Joueur tmp = listeJoueurs.get(j);
            createTableRow(tl, j, tmp.getNumero() + " " +tmp.getPseudo(),
                     row_buttons_id_def, row_buttons_str_def, row_buttons_color_def);
        }
    }

    public void createTableRow(TableLayout tl, int index, String playerName, int[] id_array, int[] str_array, int[] colors_array) {
        TableRow.LayoutParams rowParams = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        TableRow tableRow = new TableRow(getApplicationContext());

        TextView indexView = new TextView(mCtx);
        indexView.setText(String.valueOf(index));
        indexView.setVisibility(View.GONE);
        tableRow.addView(indexView);

        createText(tableRow, playerName);
        for (int j = 0; j < id_array.length; j++) {
            createButton(tableRow, str_array[j], id_array[j], colors_array[j]);
        }

        tl.addView(tableRow, rowParams);
    }

    public void createText(TableRow parent, String text) {
        float dp = parent.getResources().getDisplayMetrics().density;

        TextView textView = new TextView(getApplicationContext());
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, (int)(5 * dp), 0, 0);

        textView.setText(text);
        parent.addView(textView);
    }

    public void createButton(TableRow parent, int text, Integer id, Integer flags) {
        float dp = parent.getResources().getDisplayMetrics().density;
        if (flags == null) {
            flags = GRAY;
        }

        Button btn = new Button(getApplicationContext(), null, android.R.attr.buttonStyleSmall);
        btn.setText(text);
        btn.setTextColor(0xFF111111);
        if (id != null) {
            btn.setId(id);
        }

        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        lp.setMargins((int)(5 * dp), (int)(5 * dp), 0, 0);

        switch (flags) {
            case InterfaceMatch.RED:
                btn.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case InterfaceMatch.GREEN:
                btn.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            default:
                btn.setBackgroundColor(getResources().getColor(R.color.grey));
                break;
        }

        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ViewGroup p = (ViewGroup) v.getParent();
                TextView textView = (TextView) p.getChildAt(0);
                int index = Integer.parseInt(textView.getText().toString());

                TempsDeJeu tps = new TempsDeJeu(-1, ChronoFragment.getTime(), -1, -1);
                tableTempsDeJeu.insert(tps);

                switch (v.getId()) {
                    case R.id.tir_2:
                        Log.v("TAG", "Tir 2 Pts: " + textView.getText().toString());
                        tirReussi(tps, getActeurOff(index),2);
                        break;

                    case R.id.tir_2r:
                        Log.v("TAG", "Tir 2 Pts Raté: " + textView.getText().toString());
                        tirRate(tps, getActeurOff(index), 2);
                        break;

                    case R.id.faute_off:
                        Log.v("TAG", "Faute Off: " +textView.getText().toString());
                        fauteOffensive(tps, getActeurOff(index));
                        break;

                    case R.id.rebond_off:
                        Log.v("TAG", "Rebond Off: " +textView.getText().toString());
                        rebondOffensif(tps, getActeurOff(index));
                        break;

                    case R.id.turnover:
                        Log.v("TAG", "Turnover: " +textView.getText().toString());
                        perteDeBalle(tps, getActeurOff(index));
                        break;

                    case R.id.block:
                        Log.v("TAG", "Block: " +textView.getText().toString());
                        contre(tps, getActeurDef(index));
                        break;

                    case R.id.rebond_def:
                        Log.v("TAG", "Rebond Def: " +textView.getText().toString());
                        rebondDefensif(tps, getActeurDef(index));
                        break;

                    case R.id.faute_def:
                        Log.v("TAG", "Faute Def: " +textView.getText().toString());
                        fauteDefensive(tps, getActeurDef(index));
                        break;

                    case R.id.steal:
                        Log.v("TAG", "Steal: " +textView.getText().toString());
                        interception(tps, getActeurDef(index));
                        break;
                }
            }
        });

        parent.addView(btn, lp);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_interface_match, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.voir_bdd) {
            Intent intent = new Intent(this, VerificationDB.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void initDAO(Context context){
        tableEquipe = new DBEquipeDAO(context);
        tableJoueur = new DBJoueurDAO(context);
        tableShoot = new DBShootDAO(context);
        tableContre = new DBContreDAO(context);
        tableFaute = new DBFauteDAO(context);
        tableInterception = new DBInterceptionDAO(context);
        tablePasse = new DBPasseDAO(context);
        tablePerteBalle = new DBPerteBalleDAO(context);
        tableRebond = new DBRebondDAO(context);
        tableTempsDeJeu = new DBTempsDeJeuDAO(context);
    }

    public void tirReussi(TempsDeJeu tps, Joueur acteur, int pts){
        Shoot tir = new Shoot(tableTempsDeJeu.getLast(), acteur, pts, 1);
        tableShoot.insert(tir);
        addHistorique(tps.getChronometre() + "\t==tir 2 pts réussi par\t" + acteur.getPseudo());
        Log.v("TAG", "Insertion shoot réussi à" + pts + " pts");
    }

    public void tirRate(TempsDeJeu tps, Joueur acteur, int pts){
        Shoot tir = new Shoot(tableTempsDeJeu.getLast(), acteur, pts, 0);
        tableShoot.insert(tir);
        addHistorique(tps.getChronometre() + "\ttir 2 pts réussi par\t"+acteur.getPseudo());
        Log.v("TAG", "Insertion shoot loupé à" + pts + " pts");
    }

    public void rebondOffensif(TempsDeJeu tps, Joueur acteur){
        tableRebond.insert(new Rebond(tableTempsDeJeu.getLast(), acteur, "OFF"));
        addHistorique(tps.getChronometre() + "\trebond offensif de\t"+acteur.getPseudo());
        Log.v("TAG", "Insertion rebond off");

    }

    public void rebondDefensif(TempsDeJeu tps, Joueur acteur){
        tableRebond.insert(new Rebond(tableTempsDeJeu.getLast(), acteur, "DEF"));
        addHistorique(tps.getChronometre() + "\trebond défensif de\t"+acteur.getPseudo());
        Log.v("TAG", "Insertion rebond def");
    }

    public void fauteOffensive(TempsDeJeu tps, Joueur acteur){
        addHistorique(tps.getChronometre() + "\tfaute de\t"+acteur.getPseudo());
        tableFaute.insert(new Faute(tableTempsDeJeu.getLast(), acteur));
    }

    public void fauteDefensive(TempsDeJeu tps, Joueur acteur){
        tableFaute.insert(new Faute(tableTempsDeJeu.getLast(), acteur));
        addHistorique(tps.getChronometre() + "\tfaute de\t"+acteur.getPseudo());
    }

    public void interception(TempsDeJeu tps, Joueur acteur){
        tableInterception.insert(new Interception(tableTempsDeJeu.getLast(), acteur));
        addHistorique(tps.getChronometre() + "\tinterception de\t"+acteur.getPseudo());

    }

    public void perteDeBalle(TempsDeJeu tps, Joueur acteur){
        tablePerteBalle.insert(new PerteBalle(tableTempsDeJeu.getLast(), acteur));
        addHistorique(tps.getChronometre() + "\tballon perdu par\t"+acteur.getPseudo());
    }

    public void contre(TempsDeJeu tps, Joueur acteur){
        tableContre.insert(new Contre(tableTempsDeJeu.getLast(), acteur));
        addHistorique(tps.getChronometre() + "\tcontre de\t"+acteur.getPseudo());
    }

    public void fillTeamLayouts(){
        if (equipeOff == tableEquipe.getEquipeId(nomEquipeA)) {
            createOffenseLayout(tableLayoutLeft, listeJoueursA);
            createDefenseLayout(tableLayoutRight, listeJoueursB);
        }
        else {
            createOffenseLayout(tableLayoutRight, listeJoueursB);
            createDefenseLayout(tableLayoutLeft, listeJoueursA);
        }
    }

    public Joueur getActeurOff(int index){
        if (equipeOff == idA)
            return listeJoueursA.get(index);
        else
            return listeJoueursB.get(index);
    }

    public Joueur getActeurDef(int index){
        if (equipeOff == idA)
            return listeJoueursB.get(index);
        else
            return listeJoueursA.get(index);
    }

    public void clearLayouts(){
        tableLayoutLeft.removeAllViews();
        tableLayoutRight.removeAllViews();
    }

    public void switchPossession(){
        if (equipeOff == idA)
            equipeOff = idB;
        else
            equipeOff = idA;
        clearLayouts();
        fillTeamLayouts();
    }

    public void switchPossession(View view){
        if (equipeOff == idA)
            equipeOff = idB;
        else
            equipeOff = idA;
        clearLayouts();
        fillTeamLayouts();
    }

    public void initHistorique(){
        mHistoriqueListView = (ListView) findViewById(R.id.history_listview);
        mHistorique = new ArrayList<String>();
        mHistoriqueListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mHistorique);
        mHistoriqueListView.setAdapter(mHistoriqueListAdapter);
    }

    public void addHistorique(String str){
        mHistorique.add(0,str);
        mHistoriqueListAdapter.notifyDataSetChanged();
        mHistoriqueListView.setAdapter(mHistoriqueListAdapter);
    }

    public void deleteHistorique(){
        //TODO with onSelectedItem imo sur la listView
    }
}

package com.enseirb.pfa.bastats.data.model.action;

import com.enseirb.pfa.bastats.data.model.TempsDeJeu;

/**
 * Created by rchabot on 25/01/15.
 */
public class Contre {
    private static int NO_ID = -1;

    private int id;
    private int tempsDeJeu;
    private int joueurActeur;
    private String  commentaire;

    private int joueurCible;

    public Contre() {
        setTempsDeJeu(NO_ID);
        setJoueurActeur(NO_ID);
        setCommentaire("");
        setJoueurCible(NO_ID);
    }

    public Contre(TempsDeJeu temps, Joueur joueurActeur, Joueur joueurCible) {
        setTempsDeJeu(temps.getId());
        setJoueurActeur(joueurActeur.getId());
        setCommentaire("");
        setJoueurCible(joueurCible.getId());
    }

    public Contre(TempsDeJeu temps, Joueur joueurActeur) {
        setTempsDeJeu(temps.getId());
        setJoueurActeur(joueurActeur.getId());
        setCommentaire("");
        setJoueurCible(NO_ID);
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTempsDeJeu() {
        return tempsDeJeu;
    }

    public void setTempsDeJeu(int tempsDeJeu) {
        this.tempsDeJeu = tempsDeJeu;
    }

    public int getJoueurActeur() {
        return joueurActeur;
    }

    public void setJoueurActeur(int joueurActeur) {
        this.joueurActeur = joueurActeur;
    }

    public int getJoueurCible() {
        return joueurCible;
    }

    public void setJoueurCible(int joueurCible) {
        this.joueurCible = joueurCible;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire){
        this.commentaire = commentaire;
    }

    @Override
    public String toString(){
        return "Tps:"+getTempsDeJeu()+"\tJoueur: "+getJoueurActeur()+"\tCible: "+getJoueurCible()+
                "\tId: "+getId();
    }

}

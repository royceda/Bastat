package com.enseirb.pfa.bastats;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.enseirb.pfa.bastats.data.DAO.DBEquipeDAO;
import com.enseirb.pfa.bastats.data.DAO.DBJoueurDAO;
import com.enseirb.pfa.bastats.data.model.Equipe;
import com.enseirb.pfa.bastats.data.model.action.Joueur;

import java.util.ArrayList;
import java.util.HashMap;


public class TeamSelection extends ActionBarActivity {

    private ListView listB;
    private ArrayList<HashMap<String,String>> personnesB=new ArrayList<HashMap<String, String>>();
    private SimpleAdapter adapterB;
    private Button ajoutB;
    private EditText joueurB;
    private EditText numB;
    private EditText equipeB;

    private ListView listA;
    ArrayList<HashMap<String,String>> personnesA=new ArrayList<HashMap<String, String>>();
    private SimpleAdapter adapterA;
    private Button ajoutA;
    private EditText joueurA;
    private EditText numA;
    private EditText equipeA;

    private final static int dialogA=1;
    private final static int dialogB=2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_selection);

        listB=(ListView) findViewById(R.id.listB);
        ajoutB=(Button) findViewById(R.id.ajoutB);
        joueurB=(EditText) findViewById(R.id.nomJoueurB);
        listA=(ListView) findViewById(R.id.listA);
        ajoutA=(Button) findViewById(R.id.ajoutA);
        joueurA=(EditText) findViewById(R.id.nomJoueurA);
        numA=(EditText) findViewById(R.id.numeroJoueurA);
        numB=(EditText) findViewById(R.id.numeroJoueurB);
        equipeA=(EditText) findViewById(R.id.equipeA);
        equipeB=(EditText) findViewById(R.id.equipeB);


        ajoutB.setOnClickListener(new AjoutJoueurB());
        adapterB=new SimpleAdapter(this,personnesB,R.layout.player,new String[]{"num","nom"},new int[]{R.id.joueurB,R.id.num});
        listB.setAdapter(adapterB);


        ajoutA.setOnClickListener(new AjoutJoueurA());
        adapterA=new SimpleAdapter(this,personnesA,R.layout.player,new String[]{"num","nom"},new int[]{R.id.joueurB,R.id.num});
        listA.setAdapter(adapterA);

    }


    public Dialog onCreateDialog(int id){
        AlertDialog dialog=null;

        switch(id){
            case dialogB:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Etes-vous sur d'ajouter "+numB.getText()+" "+joueurB.getText().toString()+ "? ");
                builder.setCancelable(true);
                builder.setPositiveButton("Oui", new AjoutB());
                builder.setNegativeButton("Non",new NonAjoutB());
                dialog = builder.create();
                break;
            case dialogA:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
                builder2.setMessage("Etes-vous sur d'ajouter "+numA.getText()+" "+joueurA.getText().toString()+ "? ");
                builder2.setCancelable(true);
                builder2.setPositiveButton("Oui", new AjoutA());
                builder2.setNegativeButton("Non",new NonAjoutA());
                dialog = builder2.create();
                break;
        }
        return dialog;
    }

    public void onPrepareDialog(int id,Dialog dialog){
        switch(id){
            case dialogB:
                ((AlertDialog) dialog).setMessage("Etes-vous sur d'ajouter "+numB.getText()+" "+joueurB.getText().toString()+ "? ");
                break;
            case dialogA:
                ((AlertDialog) dialog).setMessage("Etes-vous sur d'ajouter "+numA.getText()+" "+joueurA.getText().toString()+ "? ");
        }
    }


    class NonAjoutA implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which) {
            joueurA.setText("");
            numA.setText("");
        }
    }

    class AjoutA implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which) {
            HashMap<String,String> map=new HashMap<String,String>();
            map.put("num", numA.getText().toString());
            map.put("nom", joueurA.getText().toString());
            personnesA.add(map);
            adapterA=new SimpleAdapter(TeamSelection.this,personnesA,R.layout.player,new String[]{"num","nom"},new int[]{R.id.num,R.id.joueurB});
            listA.setAdapter(adapterA);
            joueurA.setText("");
            numA.setText("");
        }
    }


    class NonAjoutB implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which) {
            joueurB.setText("");
            numB.setText("");
        }
    }


    class AjoutB implements DialogInterface.OnClickListener{
        @Override
        public void onClick(DialogInterface dialog, int which) {
            HashMap<String,String> map=new HashMap<String,String>();
            map.put("num", numB.getText().toString());
            map.put("nom", joueurB.getText().toString());
            personnesB.add(map);
            adapterB=new SimpleAdapter(TeamSelection.this,personnesB,R.layout.player,new String[]{"num","nom"},new int[]{R.id.num,R.id.joueurB});
            listB.setAdapter(adapterB);
            joueurB.setText("");
            numB.setText("");
        }
    }

    class AjoutJoueurB implements View.OnClickListener{
        @SuppressWarnings("deprecation")
        @Override
        public void onClick(View v) {
            showDialog(dialogB);
        }
    }


    class AjoutJoueurA implements View.OnClickListener{
        @SuppressWarnings("deprecation")
        @Override
        public void onClick(View v) {
            showDialog(dialogA);
        }
    }

    public void startInterfaceMatch(View view) {
        DBEquipeDAO dbe=new DBEquipeDAO(TeamSelection.this);
        DBJoueurDAO dbj=new DBJoueurDAO(TeamSelection.this);
        dbe.insert(new Equipe(equipeA.getText().toString().trim()));
        dbe.insert(new Equipe(equipeB.getText().toString().trim()));
        int idA=dbe.getEquipeId(equipeA.getText().toString().trim());
        int idB=dbe.getEquipeId(equipeB.getText().toString().trim());

        for(int i=0;i<personnesA.size();i++){
            Joueur j = new Joueur(personnesA.get(i).get("nom"),
                                  Integer.parseInt(personnesA.get(i).get("num")),idA);
            //Joueur j = new Joueur("Maurice", 5, idA);
            dbj.insert(j);
        }

        for(int i=0;i<personnesB.size();i++) {
            Joueur j = new Joueur(personnesB.get(i).get("nom"),
                                  Integer.parseInt(personnesB.get(i).get("num")),idB);
            //Joueur j = new Joueur("MauriceB", 7, idB);
            dbj.insert(j);
        }
        // Do something in response to button
        Intent intent = new Intent(this, InterfaceMatch.class);
        intent.putExtra("equipeA",equipeA.getText().toString().trim());
        intent.putExtra("equipeB",equipeB.getText().toString().trim());
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_team_selection, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}